import React, { useRef, useState } from 'react';
import { MarketingPlanState } from '../types';
import { Award, Share2, Printer, RotateCcw, Copy, Check, Sparkles, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const renderMarketingItem = (item: string) => {
  const tokens = item.split(' ');
  if (tokens.length > 1) {
    const firstToken = tokens[0];
    const isEmoji = /[\uD800-\uDFFF\u2600-\u27BF]/.test(firstToken) || (firstToken.length > 0 && firstToken.charCodeAt(0) > 127);
    if (isEmoji) {
      return tokens.slice(1).join(' ');
    }
  }
  return item;
};

interface FinalPosterProps {
  plan: MarketingPlanState;
  onReset: () => void;
  presetEmoji: string;
}

export default function FinalPoster({
  plan,
  onReset,
  presetEmoji,
}: FinalPosterProps) {
  const [copied, setCopied] = useState(false);
  const printAreaRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyToClipboard = () => {
    const textToCopy = `
=========================================
🚀 ${plan.productTitle.toUpperCase()} - MARKETING PLAN 🚀
=========================================
Concept: ${plan.productDescription}

-----------------------------------------
🔍 TARGET CUSTOMER SEGMENT (Hero Profiler)
-----------------------------------------
• Hero Character Name: ${plan.segmentation.heroName || 'Not drafted'}
• Targets Age: ${plan.segmentation.heroAge} years old
• Sweet Hobby: ${plan.segmentation.heroHobby || 'Not drafted'}
• Main Struggle: ${plan.segmentation.heroPainPoint || 'Not drafted'}
• Where they gather: ${plan.segmentation.heroHangout || 'Not drafted'}

-----------------------------------------
🎯 BRAND POSITIONING MAD LIBS
-----------------------------------------
"Our business is designed for ${plan.positioning.targetHero || '(Audience)'} who are tired of ${plan.positioning.problem || '(Issue)'}. Unlike ${plan.positioning.competitor || '(Competitors)'}, we bring ${plan.positioning.uniqueFeature || '(Secret Sauce)'} because we strongly believe that ${plan.positioning.brandValue || '(Mission)'}."

-----------------------------------------
🛠️ THE 4PS MARKETING BLUEPRINT
-----------------------------------------
1. PRODUCT (What you sell):
   - Packaging choice: ${plan.fourPs.productPackaging || 'Not drafted'}
   - Key attributes:
     ${plan.fourPs.productFeatures.map((f) => `• ${f}`).join('\n     ') || '• No specific entries yet.'}

2. PRICE (What you earn):
   - Costs per unit: $${plan.fourPs.costToMake}
   - Retail target price: $${plan.fourPs.sellingPrice}
   - Profit value per unit: $${Number(plan.fourPs.sellingPrice - plan.fourPs.costToMake).toFixed(2)}

3. PLACE (Where you sell):
   ${plan.fourPs.placesToSell.map((p) => `• ${renderMarketingItem(p)}`).join('\n   ') || '• No placement slots targeted yet.'}

4. PROMOTION (How you hype):
   • Advertising & Promo Strategy:
     ${plan.fourPs.promoStrategies.map((pr) => `• ${renderMarketingItem(pr)}`).join('\n     ') || '• No specific promotional plans yet.'}
   • Core Marketing Channels:
     ${(plan.fourPs.promoChannels || []).map((ch) => `• ${renderMarketingItem(ch)}`).join('\n     ') || '• No specific channels targetted yet.'}
=========================================
Plan locked with Rank: Chief Marketing Officer (CMO) 👑
=========================================
    `;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Upper Congrats Ribbon */}
      <div className="bg-linear-to-r from-emerald-500/90 via-indigo-600/95 to-pink-500/95 rounded-3xl p-6 text-white text-center shadow-xl relative overflow-hidden border border-white/20 backdrop-blur-sm">
        {/* Confetti stars bg glow */}
        <div className="absolute inset-0 bg-radial-to-t from-transparent to-slate-900/20" />

        <div className="relative z-10 flex flex-col items-center gap-3">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-4xl animate-bounce">
            🎉
          </div>
          <h2 className="text-2xl md:text-3xl font-black tracking-tight mt-1 font-display">
            CONGRATULATIONS, CHIEF MARKETING OFFICER!
          </h2>
          <p className="text-xs md:text-sm text-indigo-100 max-w-xl font-bold leading-relaxed">
            You completed every interactive planning puzzle. Your business plan is fully locked, loaded,
            and ready to pitch to the judges panel!
          </p>

          <div className="flex flex-wrap gap-3 mt-4">
            <button
              id="btn-print-poster"
              onClick={handlePrint}
              className="bg-white text-indigo-700 hover:bg-slate-50 font-black text-xs px-4.5 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" /> Print / PDF Print
            </button>
            <button
              id="btn-copy-markdown"
              onClick={handleCopyToClipboard}
              className="bg-indigo-900/40 hover:bg-indigo-900/70 text-white border border-white/20 font-black text-xs px-4.5 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied Details!' : 'Copy Markdown Text'}
            </button>
            <button
              id="btn-reset-board"
              onClick={onReset}
              className="bg-slate-950/40 hover:bg-slate-950/65 text-indigo-150 border border-white/10 font-black text-xs px-4.5 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" /> Start New Pitch
            </button>
          </div>
        </div>
      </div>

      {/* Main Print Wrapper Block */}
      <div
        ref={printAreaRef}
        className="glass-card print:bg-white rounded-3xl border border-white/65 p-6 md:p-8 shadow-xl print:shadow-none print:border-none relative z-15"
      >
        {/* Certificate Watermark Stamp */}
        <div className="absolute top-10 right-10 opacity-5 select-none text-[80px] font-black tracking-tighter text-indigo-950 uppercase rotate-12 hidden md:block print:hidden">
          CMO PITCH
        </div>

        {/* Poster Grid Board */}
        <div className="space-y-8">
          {/* Header of Poster */}
          <div className="text-center pb-6 border-b-4 border-slate-900">
            <div className="flex justify-center text-5xl mb-2">{presetEmoji || '🚀'}</div>
            <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
              {plan.productTitle.toUpperCase()}
            </h1>
            <p className="text-slate-500 font-bold uppercase tracking-widest text-xs mt-1">
              Official Competitive Marketing Plan Blueprint
            </p>
            <p className="text-sm text-slate-600 font-medium max-w-2xl mx-auto mt-2 leading-relaxed italic">
              "{plan.productDescription}"
            </p>
          </div>

          {/* Core Row 1: Target Hero Profile & Mad Libs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
            {/* Box 1: Target Hero Segment */}
            <div className="bg-white/40 backdrop-blur-md border border-white/50 rounded-2xl p-5 relative overflow-hidden shadow-xs">
              <span className="absolute top-0 right-0 bg-indigo-500/10 text-indigo-700 border-l border-b border-indigo-200/20 font-extrabold text-[9px] px-2.5 py-1 uppercase rounded-bl-xl tracking-widest">
                Target Customer
              </span>
              <h3 className="text-sm font-black text-indigo-950 flex items-center gap-1.5 border-b border-indigo-200/30 pb-2 mb-3 font-display">
                🔍 TARGET PROFILE CARD
              </h3>

              <div className="space-y-3 pt-1 text-xs text-slate-800">
                <p>
                  <strong className="text-slate-400 uppercase text-[9px] font-black tracking-wider block">Hero character name:</strong>
                  <span className="text-sm font-extrabold text-slate-850">
                    {plan.segmentation.heroName || 'Unspecified'}
                  </span>
                </p>
                <p>
                  <strong className="text-slate-400 uppercase text-[9px] font-black tracking-wider block">Age bracket:</strong>
                  <span className="text-sm font-extrabold text-slate-850">{plan.segmentation.heroAge} years old</span>
                </p>
                <p>
                  <strong className="text-slate-400 uppercase text-[9px] font-black tracking-wider block">Preferred pass-time hobby:</strong>
                  <span className="text-sm font-extrabold text-slate-850">
                    {plan.segmentation.heroHobby || 'Unspecified'}
                  </span>
                </p>
                <p>
                  <strong className="text-slate-400 uppercase text-[9px] font-black tracking-wider block">Primary struggle point:</strong>
                  <span className="text-sm font-extrabold text-slate-850">
                    {plan.segmentation.heroPainPoint || 'Unspecified'}
                  </span>
                </p>
                <p>
                  <strong className="text-slate-400 uppercase text-[9px] font-black tracking-wider block">Advertising hangar/media:</strong>
                  <span className="text-sm font-extrabold text-slate-850">
                    {plan.segmentation.heroHangout || 'Unspecified'}
                  </span>
                </p>
              </div>
            </div>

            {/* Box 2: Positioning Formula statement */}
            <div className="bg-white/40 backdrop-blur-md border border-white/50 rounded-2xl p-5 relative overflow-hidden shadow-xs">
              <span className="absolute top-0 right-0 bg-yellow-500/10 text-amber-800 border-l border-b border-amber-200/20 font-extrabold text-[9px] px-2.5 py-1 uppercase rounded-bl-xl tracking-widest">
                Positioning
              </span>
              <h3 className="text-sm font-black text-amber-900 flex items-center gap-1.5 border-b border-amber-200/30 pb-2 mb-3 font-display">
                🎯 SECRET BRAND POSITIONING
              </h3>

              <div className="text-xs font-semibold tracking-wide text-slate-800 leading-relaxed font-sans space-y-3.5 pt-1">
                <p>
                  "Our business model is built exclusively for{' '}
                  <span className="bg-amber-100/60 text-amber-950 font-black px-1.5 py-0.5 rounded-lg border border-amber-200/30">
                    {plan.positioning.targetHero || 'Unspecified Segment'}
                  </span>{' '}
                  who struggle with daily{' '}
                  <span className="bg-indigo-100/60 text-indigo-950 font-black px-1.5 py-0.5 rounded-lg border border-indigo-200/30">
                    {plan.positioning.problem || 'Unspecified Problem'}
                  </span>
                  ."
                </p>
                <p>
                  "Unlike the main competitor brands, which provide{' '}
                  <span className="bg-pink-100/60 text-pink-950 font-black px-1.5 py-0.5 rounded-lg border border-pink-200/30">
                    {plan.positioning.competitor || 'Unspecified Competitors'}
                  </span>
                  , we offer{' '}
                  <span className="bg-emerald-100/60 text-emerald-950 font-black px-1.5 py-0.5 rounded-lg border border-emerald-200/30">
                    {plan.positioning.uniqueFeature || 'Unspecified secret sauce'}
                  </span>{' '}
                  because we strongly believe{' '}
                  <span className="bg-cyan-100/60 text-cyan-950 font-black px-1.5 py-0.5 rounded-lg border border-cyan-200/30">
                    {plan.positioning.brandValue || 'Unspecified Values'}
                  </span>
                  ."
                </p>
              </div>
            </div>
          </div>

          {/* Row 2: The 4Ps Strategy Grid */}
          <div className="border-t border-indigo-200/30 pt-7 relative z-10">
            <h3 className="text-sm font-black text-indigo-950 uppercase tracking-widest text-center mb-6 font-display">
              🛠️ THE 4Ps MARKETING BLUEPRINT
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
              {/* P1: Product */}
              <div className="bg-white/40 backdrop-blur-md border border-white/50 rounded-2xl p-4.5 flex flex-col justify-between shadow-xs">
                <div>
                  <div className="flex justify-between items-center bg-emerald-500/10 text-emerald-800 border border-emerald-500/10 px-3 py-1 rounded-xl mb-4">
                    <span className="text-[10px] font-black uppercase tracking-wider">P1 • PRODUCT</span>
                    <span className="text-xs">💡</span>
                  </div>

                  <p className="text-[9px] text-slate-400 font-black uppercase mt-1">Design Packaging</p>
                  <p className="text-xs font-extrabold text-slate-800 mt-1 bg-white/45 p-2.5 rounded-xl border border-white/40 leading-snug">
                    {plan.fourPs.productPackaging || 'Not defined yet'}
                  </p>

                  <p className="text-[9px] text-slate-400 font-black uppercase mt-3.5 mb-1.5">Top Features</p>
                  <ul className="space-y-1.5 text-[11px] font-bold text-slate-700">
                    {plan.fourPs.productFeatures.length === 0 ? (
                      <li className="italic text-slate-400">None defined.</li>
                    ) : (
                      plan.fourPs.productFeatures.map((feat, idx) => (
                        <li key={idx} className="flex items-center gap-1 bg-white/30 px-2.5 py-1 rounded-lg border border-white/10 text-slate-800">
                          <span className="text-emerald-500 font-bold">•</span>
                          {feat}
                        </li>
                      ))
                    )}
                  </ul>
                </div>
              </div>

              {/* P2: Pricing */}
              <div className="bg-white/40 backdrop-blur-md border border-white/50 rounded-2xl p-4.5 flex flex-col justify-between shadow-xs">
                <div>
                  <div className="flex justify-between items-center bg-amber-500/10 text-amber-800 border border-amber-500/10 px-3 py-1 rounded-xl mb-4">
                    <span className="text-[10px] font-black uppercase tracking-wider">P2 • PRICE</span>
                    <span className="text-xs">💰</span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-bold uppercase text-[9px] tracking-wider">Cost to create:</span>
                      <span className="font-mono font-black text-slate-800">${plan.fourPs.costToMake}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-bold uppercase text-[9px] tracking-wider">Mailing Price:</span>
                      <span className="font-mono font-black text-slate-800">${plan.fourPs.sellingPrice}</span>
                    </div>
                    <div className="flex justify-between pt-1.5 border-t border-dashed border-slate-200/40">
                      <span className="text-slate-500 font-bold uppercase text-[9px] tracking-wider">Margin Profit:</span>
                      <span className="font-mono font-black text-emerald-600">
                        +${Number(plan.fourPs.sellingPrice - plan.fourPs.costToMake).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-white/50 border border-white/40 p-2 text-center rounded-xl mt-4">
                  <p className="text-[9px] text-slate-400 font-black uppercase">Math Ratio Status</p>
                  <p className="text-xs text-slate-700 font-extrabold mt-0.5">
                    {plan.fourPs.sellingPrice > plan.fourPs.costToMake
                      ? '✅ Safe Margin Approved!'
                      : '⚠️ Unit Cost is Higher! Fix Prices!'}
                  </p>
                </div>
              </div>

              {/* P3: Place */}
              <div className="bg-white/40 backdrop-blur-md border border-white/50 rounded-2xl p-4.5 flex flex-col justify-between shadow-xs">
                <div>
                  <div className="flex justify-between items-center bg-blue-500/10 text-blue-800 border border-blue-500/10 px-3 py-1 rounded-xl mb-4">
                    <span className="text-[10px] font-black uppercase tracking-wider">P3 • PLACE</span>
                    <span className="text-xs">📍</span>
                  </div>

                  <p className="text-[9px] text-slate-400 font-black uppercase mb-2">Primary Sales Channels</p>
                  <ul className="space-y-1.5 text-[11px] font-bold text-slate-700">
                    {plan.fourPs.placesToSell.length === 0 ? (
                      <li className="italic text-slate-400">No channels targeted.</li>
                    ) : (
                      plan.fourPs.placesToSell.map((p, idx) => (
                        <li key={idx} className="bg-white/30 px-2.5 py-1 rounded-lg border border-white/10 text-slate-800 break-words leading-tight">
                          <span className="text-blue-500 font-bold mr-1">✓</span>
                          {renderMarketingItem(p)}
                        </li>
                      ))
                    )}
                  </ul>
                </div>
              </div>

              {/* P4: Promotion */}
              <div className="bg-white/40 backdrop-blur-md border border-white/50 rounded-2xl p-4.5 flex flex-col justify-between shadow-xs">
                <div>
                  <div className="flex justify-between items-center bg-pink-500/10 text-pink-750 border border-pink-500/10 px-3 py-1 rounded-xl mb-4">
                    <span className="text-[10px] font-black uppercase tracking-wider">P4 • PROMOTION</span>
                    <span className="text-xs">📣</span>
                  </div>

                  {/* Advertising & Promo Plan */}
                  <div className="mb-3">
                    <p className="text-[9px] text-slate-400 font-black uppercase mb-1">📣 Advertising & Promo Plan</p>
                    <ul className="space-y-1 text-[11.5px] font-bold text-slate-700">
                      {plan.fourPs.promoStrategies.length === 0 ? (
                        <li className="italic text-slate-400">No activities selected.</li>
                      ) : (
                        plan.fourPs.promoStrategies.map((p, idx) => (
                          <li key={idx} className="bg-white/30 px-2.5 py-1 rounded-lg border border-white/10 text-slate-800 break-words leading-tight">
                            <span className="text-pink-500 font-bold mr-1">✦</span>
                            {renderMarketingItem(p)}
                          </li>
                        ))
                      )}
                    </ul>
                  </div>

                  {/* Marketing Channels */}
                  <div>
                    <p className="text-[9px] text-slate-400 font-black uppercase mb-1">📱 Marketing Channels</p>
                    <ul className="space-y-1 text-[11.5px] font-bold text-slate-705">
                      {!plan.fourPs.promoChannels || plan.fourPs.promoChannels.length === 0 ? (
                        <li className="italic text-slate-400">No channels targeted.</li>
                      ) : (
                        plan.fourPs.promoChannels.map((p, idx) => (
                          <li key={idx} className="bg-white/30 px-2.5 py-1 rounded-lg border border-white/10 text-slate-800 break-words leading-tight">
                            <span className="text-indigo-600 font-bold mr-1">✓</span>
                            {renderMarketingItem(p)}
                          </li>
                        ))
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer of Poster - Competition Seals */}
          <div className="border-t border-dashed border-indigo-200/40 pt-5 flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400">OFFICIAL RECOGNITION:</span>
              <span className="bg-white/50 border border-indigo-200/30 text-indigo-950 font-mono text-[9px] px-2 py-0.5 rounded font-black shadow-xs">
                LEVEL_CMO_APPROVED
              </span>
            </div>
            <p className="text-[11px] text-slate-405 font-bold leading-none">
              Generated via Launchpad Teen Marketing Planner
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

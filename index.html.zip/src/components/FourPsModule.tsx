import React, { useState, useEffect } from 'react';
import { FourPsState, PresetBusiness } from '../types';
import { ShoppingBag, DollarSign, MapPin, Megaphone, Coins, Sparkles, Plus, Trash, Check, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FourPsProps {
  initialData: FourPsState;
  preset: PresetBusiness | undefined;
  productTitle?: string;
  productDescription?: string;
  onSave: (data: FourPsState) => void;
  onNext: () => void;
  activeP: 'product' | 'pricing' | 'place' | 'promotion';
  onGoToP: (p: 'product' | 'pricing' | 'place' | 'promotion') => void;
}

export default function FourPsModule({
  initialData,
  preset,
  productTitle,
  productDescription,
  onSave,
  onNext,
  activeP,
  onGoToP,
}: FourPsProps) {
  const [formData, setFormData] = useState<FourPsState>({ ...initialData });
  const [newFeature, setNewFeature] = useState('');
  const [itemsProjected, setItemsProjected] = useState(100);
  const [newCustomPlace, setNewCustomPlace] = useState('');
  const [newCustomPromoPlan, setNewCustomPromoPlan] = useState('');
  const [newCustomPromoChannel, setNewCustomPromoChannel] = useState('');

  // Auto-generation states
  const [isGeneratingFeatures, setIsGeneratingFeatures] = useState(false);
  const [isGeneratingPackaging, setIsGeneratingPackaging] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // Sync state upward when changed
  const updateData = (updated: FourPsState) => {
    setFormData(updated);
    onSave(updated);
  };

  // AI Generation Handlers
  const handleAutoGenerateFeatures = async () => {
    setGenerationError(null);
    setIsGeneratingFeatures(true);
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productTitle: productTitle || preset?.title || "My Cool Product",
          productDescription: productDescription || preset?.description || "",
          type: "features"
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to generate features");
      }

      const data = await response.json();
      if (data.features && data.features.length > 0) {
        const updated = {
          ...formData,
          productFeatures: data.features
        };
        updateData(updated);
      } else {
        throw new Error("Empty features returned");
      }
    } catch (err: any) {
      console.warn("API feature generation failed, falling back", err);
      // Fallback to preset if available
      if (preset?.suggestedFourPs?.productFeatures) {
        const updated = {
          ...formData,
          productFeatures: [...preset.suggestedFourPs.productFeatures]
        };
        updateData(updated);
        setGenerationError("Used offline template suggestions because Gemini API key is not configured.");
      } else {
        // Fallback custom defaults
        const customDefaults = [
          "✨ Ultra-durable body built with eco-materials",
          "🌟 Personalized dynamic color overlays",
          "⚡ Safe, high-efficiency smart-charge utility"
        ];
        const updated = {
          ...formData,
          productFeatures: customDefaults
        };
        updateData(updated);
        setGenerationError(`Using offline ideas because of error: ${err.message}.`);
      }
    } finally {
      setIsGeneratingFeatures(false);
    }
  };

  const handleAutoGeneratePackaging = async () => {
    setGenerationError(null);
    setIsGeneratingPackaging(true);
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productTitle: productTitle || preset?.title || "My Cool Product",
          productDescription: productDescription || preset?.description || "",
          type: "packaging"
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to generate packaging");
      }

      const data = await response.json();
      if (data.packaging) {
        const updated = {
          ...formData,
          productPackaging: data.packaging
        };
        updateData(updated);
      } else {
        throw new Error("Empty packaging returned");
      }
    } catch (err: any) {
      console.warn("API packaging generation failed, falling back", err);
      // Fallback to preset if available
      if (preset?.suggestedFourPs?.productPackaging) {
        const updated = {
          ...formData,
          productPackaging: preset.suggestedFourPs.productPackaging
        };
        updateData(updated);
        setGenerationError("Used offline template suggestions because Gemini API key is not configured.");
      } else {
        // Fallback custom defaults
        const customDefault = "📦 Compressed zero-waste biodegradable packaging containing seed capsules";
        const updated = {
          ...formData,
          productPackaging: customDefault
        };
        updateData(updated);
        setGenerationError(`Using offline space-saver pack idea due to: ${err.message}`);
      }
    } finally {
      setIsGeneratingPackaging(false);
    }
  };

  // Preset Loaders
  useEffect(() => {
    if (preset?.suggestedFourPs) {
      // Allow merging preset
    }
  }, [preset]);

  const handleApplyPresetP = () => {
    if (preset?.suggestedFourPs) {
      const suggested = preset.suggestedFourPs;
      const updated = {
        productFeatures: [...(suggested.productFeatures || [])],
        productPackaging: suggested.productPackaging || '',
        costToMake: suggested.costToMake || 1.0,
        sellingPrice: suggested.sellingPrice || 3.0,
        placesToSell: [...(suggested.placesToSell || [])],
        promoStrategies: [...(suggested.promoStrategies || [])],
        promoChannels: [...(suggested.promoChannels || [])],
      };
      updateData(updated);
    }
  };

  // P1: Add Product Feature
  const handleAddFeature = () => {
    if (newFeature.trim()) {
      const updated = {
        ...formData,
        productFeatures: [...formData.productFeatures, newFeature.trim()],
      };
      updateData(updated);
      setNewFeature('');
    }
  };

  const handleRemoveFeature = (index: number) => {
    const updated = {
      ...formData,
      productFeatures: formData.productFeatures.filter((_, i) => i !== index),
    };
    updateData(updated);
  };

  // P3: Toggle Place Channel
  const togglePlace = (place: string) => {
    const current = formData.placesToSell;
    const nextPlaces = current.includes(place)
      ? current.filter((p) => p !== place)
      : [...current, place];

    const updated = { ...formData, placesToSell: nextPlaces };
    updateData(updated);
  };

  const handleAddCustomPlace = () => {
    if (newCustomPlace.trim()) {
      const val = newCustomPlace.trim();
      if (!formData.placesToSell.includes(val)) {
        const updated = {
          ...formData,
          placesToSell: [...formData.placesToSell, val],
        };
        updateData(updated);
      }
      setNewCustomPlace('');
    }
  };

  // P4: Toggle/Add Promotion Tactic & Marketing Channel
  const togglePromoPlan = (promo: string) => {
    const current = formData.promoStrategies;
    const nextPromos = current.includes(promo)
      ? current.filter((p) => p !== promo)
      : [...current, promo];

    const updated = { ...formData, promoStrategies: nextPromos };
    updateData(updated);
  };

  const handleAddCustomPromoPlan = () => {
    if (newCustomPromoPlan.trim()) {
      const val = newCustomPromoPlan.trim();
      if (!formData.promoStrategies.includes(val)) {
        const updated = {
          ...formData,
          promoStrategies: [...formData.promoStrategies, val],
        };
        updateData(updated);
      }
      setNewCustomPromoPlan('');
    }
  };

  const togglePromoChannel = (chan: string) => {
    const current = formData.promoChannels || [];
    const nextChannels = current.includes(chan)
      ? current.filter((c) => c !== chan)
      : [...current, chan];

    const updated = { ...formData, promoChannels: nextChannels };
    updateData(updated);
  };

  const handleAddCustomPromoChannel = () => {
    if (newCustomPromoChannel.trim()) {
      const val = newCustomPromoChannel.trim();
      const currentChannels = formData.promoChannels || [];
      if (!currentChannels.includes(val)) {
        const updated = {
          ...formData,
          promoChannels: [...currentChannels, val],
        };
        updateData(updated);
      }
      setNewCustomPromoChannel('');
    }
  };

  // Place defaults
  const placeOptions = [
    { id: 'school', label: '🏫 School Bake Sales & Tuck Shop', desc: 'Direct face-to-face sales to classmates' },
    { id: 'online', label: '💻 Online Instagram / Etsy Store', desc: 'Wide reach but requires parent postage assistance' },
    { id: 'market', label: '🎪 Weekend Artisan / Farmers Market', desc: 'Awesome place to speak with community neighbors' },
    { id: 'app', label: '📱 Mobile App Stores (Apple/Google)', desc: 'Instant global downloads for digital games' },
    { id: 'parks', label: '🎁 Pop-up Stands at Sports Parks', desc: 'Hot spot for custom quick physical gear or sweets' },
  ];

  // Promo defaults: Part 1 - Advertising and Promotion Plan
  const promoPlanOptions = [
    { id: 'tiktok_video', label: '🎥 Record a fun TikTok / Reel', desc: 'Silly trending filters, reviews, and unboxings of your product' },
    { id: 'stickers_dist', label: '🎒 Distribute holographic stickers', desc: 'Cool custom logo stickers friends paste on laptops and water bottles' },
    { id: 'assembly_pitch', label: '🎤 Presentation pitch during recess', desc: 'Gain rapid sign-ups using presentation slides and megaphone hype' },
    { id: 'discounts_deal', label: '🎟️ Launch Day Buy-1-Get-1 codes', desc: 'Invite class friends to purchase instantly' },
    { id: 'trials_free', label: '🎁 Give free trials to classmates', desc: 'Get everyone testing and talking about it' },
  ];

  // Promo defaults: Part 2 - Marketing Channels
  const promoChannelOptions = [
    { id: 'insta_tiktok', label: '📱 Instagram & TikTok accounts', desc: 'Reach your friends and public followers online' },
    { id: 'school_halls', label: '🏫 School lunchrooms & hallways', desc: 'Spread word face-to-face where everyone hangs out' },
    { id: 'gaming_com', label: '🎮 Roblox, Fortnite & Discord chat rooms', desc: 'Buzz your gaming guilds and team servers' },
    { id: 'comm_boards', label: '🎪 Local hobby shops & market pin-boards', desc: 'Pin posters where families walk by' },
    { id: 'word_mouth', label: '🎒 Direct word-of-mouth chatter', desc: 'Word spreads fast when friends love what they see!' },
  ];

  // Pricing math calculations
  const cost = formData.costToMake || 0;
  const price = formData.sellingPrice || 0;
  const singleProfit = Number((price - cost).toFixed(2));
  const profitMargin = price > 0 ? Math.round(((price - cost) / price) * 100) : 0;
  const totalRevenue = Number((price * itemsProjected).toFixed(2));
  const totalCost = Number((cost * itemsProjected).toFixed(2));
  const totalProfit = Number((singleProfit * itemsProjected).toFixed(2));

  // Kid goal feedback based on profit
  let projectedMilestone = '🌱 Seed Money startup fund!';
  let milestoneDesc = 'Excellent start! This helps buy core materials to refine your formulas.';
  let milestoneIcon = '🌱';

  if (totalProfit >= 1500) {
    projectedMilestone = '🚀 Complete Expansion Startup Mode!';
    milestoneDesc = 'Amazing! You could afford your own manufacturing line or high-scale custom gears.';
    milestoneIcon = '🚀';
  } else if (totalProfit >= 500) {
    projectedMilestone = '🍕 Class Pizza Party & Custom Prints!';
    milestoneDesc = 'Phenomenal! You would make enough pocket savings to run large school events and ads.';
    milestoneIcon = '🍕';
  } else if (totalProfit >= 100) {
    projectedMilestone = '🎧 Hot New High-End Gaming Headset!';
    milestoneDesc = 'Awesome value! This profit would easily fund nice customized luxury gaming setup items.';
    milestoneIcon = '🎧';
  } else if (totalProfit >= 30) {
    projectedMilestone = '🍿 Premium Movie Night Ticket & Popcorn!';
    milestoneDesc = 'Great job! A fun weekend reward funded entirely by your bright startup brain.';
    milestoneIcon = '🍿';
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Visual Navigation Sub-Tabs */}
      <div className="lg:col-span-3 flex flex-row lg:flex-col gap-2 overflow-x-auto pb-4 lg:pb-0 shrink-0">
        <button
          id="btn-p-product"
          onClick={() => onGoToP('product')}
          className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-left text-xs font-black transition-all shrink-0 w-[140px] lg:w-full cursor-pointer ${
            activeP === 'product'
              ? 'bg-emerald-600/90 border-emerald-500 text-white shadow-xs'
              : 'bg-white/40 border-white/25 text-slate-705 backdrop-blur-xs hover:bg-white/60'
          }`}
        >
          <ShoppingBag className="w-4 h-4 shrink-0" />
          <div className="text-left">
            <p className="text-[9px] uppercase tracking-wider opacity-80 leading-none">P1 Strategy</p>
            <p className="text-[11px] font-bold mt-1">PRODUCT</p>
          </div>
        </button>

        <button
          id="btn-p-price"
          onClick={() => onGoToP('pricing')}
          className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-left text-xs font-black transition-all shrink-0 w-[140px] lg:w-full cursor-pointer ${
            activeP === 'pricing'
              ? 'bg-amber-500/90 border-amber-400 text-white shadow-xs'
              : 'bg-white/40 border-white/25 text-slate-705 backdrop-blur-xs hover:bg-white/60'
          }`}
        >
          <DollarSign className="w-4 h-4 shrink-0" />
          <div className="text-left">
            <p className="text-[9px] uppercase tracking-wider opacity-80 leading-none">P2 Strategy</p>
            <p className="text-[11px] font-bold mt-1">PRICE</p>
          </div>
        </button>

        <button
          id="btn-p-place"
          onClick={() => onGoToP('place')}
          className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-left text-xs font-black transition-all shrink-0 w-[140px] lg:w-full cursor-pointer ${
            activeP === 'place'
              ? 'bg-blue-600/90 border-blue-500 text-white shadow-xs'
              : 'bg-white/40 border-white/25 text-slate-705 backdrop-blur-xs hover:bg-white/60'
          }`}
        >
          <MapPin className="w-4 h-4 shrink-0" />
          <div className="text-left">
            <p className="text-[9px] uppercase tracking-wider opacity-80 leading-none">P3 Strategy</p>
            <p className="text-[11px] font-bold mt-1">PLACE</p>
          </div>
        </button>

        <button
          id="btn-p-promotion"
          onClick={() => onGoToP('promotion')}
          className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-left text-xs font-black transition-all shrink-0 w-[140px] lg:w-full cursor-pointer ${
            activeP === 'promotion'
              ? 'bg-pink-600/90 border-pink-550 text-white shadow-xs'
              : 'bg-white/40 border-white/25 text-slate-705 backdrop-blur-xs hover:bg-white/60'
          }`}
        >
          <Megaphone className="w-4 h-4 shrink-0" />
          <div className="text-left">
            <p className="text-[9px] uppercase tracking-wider opacity-80 leading-none">P4 Strategy</p>
            <p className="text-[11px] font-bold mt-1">PROMOTION</p>
          </div>
        </button>

        {/* Suggestion merger inside menu */}
        <div className="hidden lg:block border border-indigo-300/30 bg-indigo-500/5 rounded-2xl p-4 mt-6 text-center">
          <p className="text-[10px] font-black text-indigo-700 uppercase tracking-widest flex items-center justify-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 animate-spin text-indigo-550" /> Suggestion Corner
          </p>
          <p className="text-[10px] text-slate-500 mt-1.5 leading-relaxed font-bold">
            Need an immediate template for this selected category? Click to seed ideas.
          </p>
          <button
            id="btn-apply-4ps-suggest"
            onClick={handleApplyPresetP}
            className="w-full bg-gradient-to-r from-indigo-550 to-purple-600 hover:from-indigo-650 hover:to-purple-700 font-extrabold text-[10px] text-white py-2 rounded-xl mt-3 shadow-xs active:scale-95 transition-all cursor-pointer"
          >
            Load 4Ps Blueprint 🪄
          </button>
        </div>
      </div>

      {/* Main Worksheet Sub-Tab Interface */}
      <div className="lg:col-span-9 glass-card rounded-3xl border border-white/65 p-5 md:p-6 shadow-md relative z-10">
        {/* P1: Product Workspace */}
        {activeP === 'product' && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <span className="text-[10px] font-black text-emerald-700 bg-emerald-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider border border-emerald-500/10">
              The Product Builder (P1)
            </span>
            <h4 className="text-xl font-extrabold text-slate-850 mt-2 font-display">What makes your Product spectacular?</h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
              Product is what you sell! Here, define the specific materials, cool ingredients, and
              the customized green packaging that makes your customer scream, "I need one!"
            </p>

            {generationError && (
              <div className="bg-amber-500/10 border border-amber-500/20 text-amber-900 rounded-2xl px-4 py-3 text-xs font-bold mt-4 flex items-start gap-2">
                <span className="text-base">💡</span>
                <span>{generationError}</span>
              </div>
            )}

            <div className="space-y-5 mt-6">
              {/* Product traits list builder */}
              <div className="bg-white/20 border border-white/35 rounded-2xl p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <label className="block text-[11px] font-black text-slate-500 uppercase tracking-widest">
                    1. List 3 of your product's awesome features or traits:
                  </label>
                  <button
                    id="btn-auto-generate-features"
                    type="button"
                    onClick={handleAutoGenerateFeatures}
                    disabled={isGeneratingFeatures}
                    className="shrink-0 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 disabled:from-indigo-300 disabled:to-indigo-400 text-white font-extrabold text-[10px] px-3.5 py-1.5 rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all shadow-xs disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isGeneratingFeatures ? 'animate-spin text-purple-200' : ''}`} />
                    {isGeneratingFeatures ? "Generating..." : "Magic Auto-Generate ✨"}
                  </button>
                </div>
                <div className="flex gap-2">
                  <input
                    id="input-product-feature"
                    type="text"
                    value={newFeature}
                    onChange={(e) => setNewFeature(e.target.value)}
                    placeholder="e.g. Glowing cotton candy, organic solar threads, extra flex base..."
                    className="flex-1 glass-input focus:bg-white/90 focus:border-emerald-500 rounded-xl px-4 py-2 text-xs font-semibold outline-hidden text-slate-800"
                    onKeyDown={(e) => e.key === 'Enter' && handleAddFeature()}
                  />
                  <button
                    id="btn-add-product-feature"
                    type="button"
                    onClick={handleAddFeature}
                    className="bg-emerald-550 hover:bg-emerald-600 text-white font-extrabold text-xs px-4 rounded-xl flex items-center gap-1 active:scale-95 transition-all shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Add
                  </button>
                </div>

                {/* Features display shelf */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {formData.productFeatures.length === 0 ? (
                    <p className="text-xs text-slate-400 font-medium italic">No features defined. Type and click Add, or use Magic Auto-Generate above!</p>
                  ) : (
                    formData.productFeatures.map((feat, idx) => (
                      <span
                        key={idx}
                        className="bg-white/80 text-emerald-800 border border-emerald-400/30 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        {feat}
                        <button
                          id={`btn-remove-feature-${idx}`}
                          onClick={() => handleRemoveFeature(idx)}
                          className="hover:text-rose-500 ml-1 font-extrabold text-xs cursor-pointer"
                        >
                          ×
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Packaging selector */}
              <div className="bg-white/20 border border-white/35 rounded-2xl p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wider">
                    2. What kind of packaging or bag does it come in?
                  </label>
                  <button
                    id="btn-auto-generate-packaging"
                    type="button"
                    onClick={handleAutoGeneratePackaging}
                    disabled={isGeneratingPackaging}
                    className="shrink-0 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 disabled:from-indigo-300 disabled:to-indigo-400 text-white font-extrabold text-[10px] px-3.5 py-1.5 rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all shadow-xs disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isGeneratingPackaging ? 'animate-spin text-purple-200' : ''}`} />
                    {isGeneratingPackaging ? "Generating..." : "Magic Auto-Generate ✨"}
                  </button>
                </div>
                <input
                  id="input-product-packaging"
                  type="text"
                  value={formData.productPackaging}
                  onChange={(e) => {
                    const updated = { ...formData, productPackaging: e.target.value };
                    updateData(updated);
                  }}
                  placeholder="e.g. Reusable cornstarch biodegradable pouch with sea-turtle sticker"
                  className="w-full glass-input focus:bg-white/90 focus:border-emerald-400 rounded-xl px-4 py-2.5 text-xs font-semibold outline-hidden transition-all text-slate-850"
                />
              </div>
            </div>

            {/* Next P button */}
            <div className="flex justify-between items-center border-t border-indigo-200/40 pt-5 mt-8">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase">Step 1 of 4 completed</span>
              <button
                id="btn-product-done"
                onClick={onNext}
                className="bg-gradient-to-r from-slate-900 to-slate-950 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl hover:opacity-95 transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                Onward to Pricing (P2) 🎉
              </button>
            </div>
          </motion.div>
        )}

        {/* P2: Pricing Workspace */}
        {activeP === 'pricing' && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <span className="text-[10px] font-black text-amber-700 bg-amber-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider border border-amber-500/10">
              The Pricing Lab (P2)
            </span>
            <h4 className="text-xl font-extrabold text-slate-850 mt-2 font-display">Setting up your startup margins</h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
              Price is how much you charge! Let's do some bright business calculation. Compare what
              it <strong>costs to make</strong> against your final <strong>selling price</strong> to
              discover your direct profits!
            </p>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-6">
              {/* Inputs shelf */}
              <div className="md:col-span-6 space-y-4">
                <div className="bg-white/20 border border-white/35 rounded-2xl p-4">
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
                      1. Cost to make 1 product:
                    </label>
                    <span className="text-[10px] text-slate-400 font-bold font-mono">(Materials, ingredients)</span>
                  </div>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      id="input-cost-make"
                      type="number"
                      step="0.01"
                      value={formData.costToMake}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        const updated = { ...formData, costToMake: val };
                        updateData(updated);
                      }}
                      className="w-full glass-input focus:bg-white/90 focus:border-amber-500 rounded-xl pl-9 pr-4 py-2 text-xs font-semibold outline-hidden text-slate-850"
                    />
                  </div>
                </div>

                <div className="bg-white/20 border border-white/35 rounded-2xl p-4">
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
                      2. Selling Price per product:
                    </label>
                    <span className="text-[10px] text-slate-400 font-bold font-mono">(What friends pay)</span>
                  </div>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      id="input-selling-unit-price"
                      type="number"
                      step="0.01"
                      value={formData.sellingPrice}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        const updated = { ...formData, sellingPrice: val };
                        updateData(updated);
                      }}
                      className="w-full glass-input focus:bg-white/90 focus:border-amber-500 rounded-xl pl-9 pr-4 py-2 text-xs font-semibold outline-hidden text-slate-850"
                    />
                  </div>
                </div>

                {/* Dream Big Interactive Slider */}
                <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-2xl p-4">
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[10px] font-black text-indigo-700 uppercase tracking-wider">
                      3. Project 1st Month Sales goal:
                    </label>
                    <span className="text-[10px] font-black text-indigo-700 bg-indigo-500/10 px-2.5 py-0.5 rounded-full">
                      {itemsProjected} items
                    </span>
                  </div>
                  <input
                    id="slider-sales-projection"
                    type="range"
                    min="10"
                    max="500"
                    step="10"
                    value={itemsProjected}
                    onChange={(e) => setItemsProjected(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 h-2 bg-indigo-200/50 rounded-full cursor-pointer mt-3"
                  />
                  <p className="text-[10px] text-indigo-900/60 leading-tight mt-2 font-bold">
                    Slide to simulate selling more units! See how volume builds serious profits.
                  </p>
                </div>
              </div>

              {/* Calculator Output Display board */}
              <div className="md:col-span-6 bg-slate-950/80 backdrop-blur-md text-white rounded-3xl p-5 border border-white/10 flex flex-col justify-between shadow-lg">
                <div>
                  <span className="text-[9px] font-bold text-amber-400 uppercase tracking-widest block">
                    📊 Live Profit Calc Simulator
                  </span>

                  <div className="grid grid-cols-2 gap-4 mt-4 border-b border-white/10 pb-3.5">
                    <div>
                      <p className="text-[10px] text-slate-505 font-bold uppercase">Profit Per Item</p>
                      <p className="text-lg font-black text-emerald-400 mt-0.5">
                        ${singleProfit > 0 ? singleProfit : '0.00'}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-505 font-bold uppercase">Profit Margin</p>
                      <p className="text-lg font-black text-amber-400 mt-0.5">
                        {profitMargin > 0 ? profitMargin : 0}%
                      </p>
                    </div>
                  </div>

                  {/* Bulk projections */}
                  <div className="space-y-2 mt-4 text-[11px]">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 font-medium">Total Business Revenue:</span>
                      <span className="font-mono text-slate-100 font-bold">${totalRevenue}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 font-medium">Total Material Costs:</span>
                      <span className="font-mono text-rose-400">-${totalCost}</span>
                    </div>

                    <div className="flex justify-between items-center text-xs pt-2 border-t border-dashed border-white/10">
                      <span className="font-semibold text-amber-200 uppercase tracking-wider">TOTAL 1st MONTH profit:</span>
                      <span className="font-mono font-black text-xl text-emerald-400">${totalProfit > 0 ? totalProfit : '0.00'}</span>
                    </div>
                  </div>
                </div>

                {/* Simulated achievement milestone */}
                <div className="bg-white/15 border border-white/10 rounded-2xl p-3.5 mt-4 flex items-start gap-2.5">
                  <span className="text-2xl pt-1 leading-none">{milestoneIcon}</span>
                  <div>
                    <h5 className="text-[10px] text-emerald-400 font-black uppercase tracking-wider leading-none">
                      {projectedMilestone}
                    </h5>
                    <p className="text-[10px] text-slate-350 leading-tight mt-1 font-semibold">
                      {milestoneDesc}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Next P button */}
            <div className="flex justify-between items-center border-t border-indigo-200/40 pt-5 mt-8">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase">Step 2 of 4 completed</span>
              <button
                id="btn-pricing-done"
                onClick={onNext}
                className="bg-gradient-to-r from-slate-900 to-slate-950 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl hover:opacity-95 transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                Onward to Placement (P3) 🎉
              </button>
            </div>
          </motion.div>
        )}

        {/* P3: Place Workspace */}
        {activeP === 'place' && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <span className="text-[10px] font-black text-blue-700 bg-blue-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider border border-blue-500/10">
              The Placement Strategy (P3)
            </span>
            <h4 className="text-xl font-extrabold text-slate-850 mt-2 font-display">Where will you showcase your goods?</h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
              Place is where customers find and buy your product. If you are selling cupcakes, school dances are perfect!
              If you build mobile apps, the App Store is key. Choose your distribution avenues below.
            </p>

            <div className="space-y-5 mt-6">
              <div>
                <p className="text-[10px] font-black text-slate-400 tracking-wider uppercase bg-slate-100/45 px-2.5 py-0.5 rounded-full inline-block mb-3">
                  IDEAS CHECKLIST (TAP TO SELECT):
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {placeOptions.map((opt) => {
                    const isSelected = formData.placesToSell.includes(opt.label);

                    return (
                      <button
                        key={opt.id}
                        id={`place-toggle-${opt.id}`}
                        onClick={() => togglePlace(opt.label)}
                        className={`text-left p-4 rounded-2xl border transition-all flex items-start gap-3.5 cursor-pointer ${
                          isSelected
                            ? 'bg-white/80 border-blue-400 text-blue-955 shadow-xs'
                            : 'bg-white/30 border-white/35 hover:bg-white/50 text-slate-800'
                        }`}
                      >
                        <div
                          className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                            isSelected ? 'border-blue-500 bg-blue-500 text-white' : 'border-slate-300 bg-white/40'
                          }`}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <h5 className="text-[13px] font-black leading-tight text-slate-850">
                            {opt.label.split(' ').slice(1).join(' ')}
                          </h5>
                          <p className="text-[11px] text-slate-500 font-bold mt-1 leading-snug">
                            {opt.desc}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Custom Input Field for Placement */}
              <div className="bg-white/20 border border-white/35 rounded-2xl p-5">
                <label className="block text-[11px] font-black text-slate-500 uppercase tracking-widest mb-1">
                  ✍️ Or enter custom places you plan to distribute or sell:
                </label>
                <div className="flex gap-2 mt-3">
                  <input
                    id="input-custom-place"
                    type="text"
                    value={newCustomPlace}
                    onChange={(e) => setNewCustomPlace(e.target.value)}
                    placeholder="e.g. Local sports center, community yard fair, friend's website..."
                    className="flex-1 glass-input focus:bg-white/90 focus:border-blue-500 rounded-xl px-4 py-2 text-xs font-semibold outline-hidden text-slate-800"
                    onKeyDown={(e) => e.key === 'Enter' && handleAddCustomPlace()}
                  />
                  <button
                    id="btn-add-custom-place"
                    type="button"
                    onClick={handleAddCustomPlace}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs px-4 rounded-xl flex items-center gap-1 active:scale-95 transition-all shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Add
                  </button>
                </div>

                {/* List dynamically added places */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {formData.placesToSell.filter(p => !placeOptions.some(opt => opt.label === p)).length === 0 ? (
                    <p className="text-xs text-slate-400 font-medium italic">No custom places added yet. Add one above!</p>
                  ) : (
                    formData.placesToSell.filter(p => !placeOptions.some(opt => opt.label === p)).map((place, idx) => (
                      <span
                        key={idx}
                        className="bg-white/80 text-blue-900 border border-blue-400/30 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5 text-blue-600" />
                        {place}
                        <button
                          id={`btn-remove-custom-place-${idx}`}
                          onClick={() => {
                            const updated = {
                              ...formData,
                              placesToSell: formData.placesToSell.filter((p) => p !== place),
                            };
                            updateData(updated);
                          }}
                          className="hover:text-rose-500 ml-1 font-extrabold text-xs cursor-pointer"
                        >
                          ×
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Next P button */}
            <div className="flex justify-between items-center border-t border-indigo-200/40 pt-5 mt-8">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase">Step 3 of 4 completed</span>
              <button
                id="btn-place-done"
                onClick={onNext}
                className="bg-gradient-to-r from-slate-900 to-slate-950 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl hover:opacity-95 transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                Onward to Promotion (P4) 🎉
              </button>
            </div>
          </motion.div>
        )}

        {/* P4: Promotion Workspace */}
        {activeP === 'promotion' && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <span className="text-[10px] font-black text-pink-700 bg-pink-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider border border-pink-500/10">
              The Promotion Buzzer (P4)
            </span>
            <h4 className="text-xl font-extrabold text-slate-850 mt-2 font-display">How will your audience learn about you?</h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
              Promotion is getting the word out! Let's choose the clever, exciting practices that build hype
              among classmates, youth groups, and teachers. Toggle our favorite ideas or write your own custom plan.
            </p>

            <div className="space-y-6 mt-6">
              {/* Part 1: How are you going to promote it (Advertising & Promotion Plan) */}
              <div className="bg-white/20 border border-white/35 rounded-2xl p-5 space-y-4">
                <div>
                  <span className="text-[10.5px] font-black text-pink-700 bg-pink-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Part 1: Your Advertising & Promotion Plan
                  </span>
                  <p className="text-[11px] text-slate-500 mt-2 font-semibold">
                    Define the fun activities, codes, giveaways, or posters you will print or announce:
                  </p>
                </div>

                {/* Part 1 Hints Checklist */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-1">
                  {promoPlanOptions.map((opt) => {
                    const isSelected = formData.promoStrategies.includes(opt.label);
                    return (
                      <button
                        key={opt.id}
                        id={`promo-plan-toggle-${opt.id}`}
                        onClick={() => togglePromoPlan(opt.label)}
                        className={`text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 cursor-pointer ${
                          isSelected
                            ? 'bg-white/80 border-pink-400 text-pink-955 shadow-xs'
                            : 'bg-white/10 border-white/30 hover:bg-white/30 text-slate-800'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                            isSelected ? 'border-pink-500 bg-pink-500 text-white' : 'border-slate-300 bg-white/40'
                          }`}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <h5 className="text-[12px] font-black leading-tight text-slate-850">
                            {opt.label.split(' ').slice(1).join(' ')}
                          </h5>
                          <p className="text-[10px] text-slate-500 font-bold mt-1 leading-snug">
                            {opt.desc}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Part 1 Custom input */}
                <div className="pt-2 border-t border-dashed border-pink-200/20">
                  <label className="block text-[10px] font-black text-slate-550 uppercase tracking-widest mb-1.5">
                    ✍️ Or add custom advertising or promotional ideas:
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="input-custom-promo-plan"
                      type="text"
                      value={newCustomPromoPlan}
                      onChange={(e) => setNewCustomPromoPlan(e.target.value)}
                      placeholder="e.g. Design customized t-shirts to wear during lunch, offer a scavenger hunt..."
                      className="flex-1 glass-input focus:bg-white/90 focus:border-pink-400 rounded-xl px-4 py-2 text-xs font-semibold outline-hidden text-slate-800"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddCustomPromoPlan()}
                    />
                    <button
                      id="btn-add-custom-promo-plan"
                      type="button"
                      onClick={handleAddCustomPromoPlan}
                      className="bg-pink-550 hover:bg-pink-600 text-white font-extrabold text-xs px-4 rounded-xl flex items-center gap-1 active:scale-95 transition-all shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" /> Add
                    </button>
                  </div>

                  {/* Display Part 1 custom tags */}
                  <div className="flex flex-wrap gap-2 mt-3.5">
                    {formData.promoStrategies.filter(p => !promoPlanOptions.some(opt => opt.label === p)).length === 0 ? (
                      <p className="text-[11px] text-slate-405 font-semibold italic">No custom advertisement plans added yet.</p>
                    ) : (
                      formData.promoStrategies.filter(p => !promoPlanOptions.some(opt => opt.label === p)).map((promo, idx) => (
                        <span
                          key={idx}
                          className="bg-white/85 text-pink-900 border border-pink-300/30 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs"
                        >
                          <Check className="w-3.5 h-3.5 text-pink-600" />
                          {promo}
                          <button
                            id={`btn-remove-custom-promo-plan-${idx}`}
                            onClick={() => {
                              const updated = {
                                ...formData,
                                promoStrategies: formData.promoStrategies.filter((p) => p !== promo),
                              };
                              updateData(updated);
                            }}
                            className="hover:text-rose-500 ml-1 font-extrabold text-xs cursor-pointer"
                          >
                            ×
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Part 2: Where are you going to promote it (Marketing Channels) */}
              <div className="bg-white/20 border border-white/35 rounded-2xl p-5 space-y-4">
                <div>
                  <span className="text-[10.5px] font-black text-indigo-700 bg-indigo-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Part 2: Your Core Marketing Channels
                  </span>
                  <p className="text-[11px] text-slate-500 mt-2 font-semibold">
                    Choose or enter where you will distribute the news (online grids, community slots, forums):
                  </p>
                </div>

                {/* Part 2 Hints Checklist */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-1">
                  {promoChannelOptions.map((opt) => {
                    const isSelected = (formData.promoChannels || []).includes(opt.label);
                    return (
                      <button
                        key={opt.id}
                        id={`promo-channel-toggle-${opt.id}`}
                        onClick={() => togglePromoChannel(opt.label)}
                        className={`text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 cursor-pointer ${
                          isSelected
                            ? 'bg-white/80 border-indigo-400 text-indigo-955 shadow-xs'
                            : 'bg-white/10 border-white/30 hover:bg-white/30 text-slate-800'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                            isSelected ? 'border-indigo-500 bg-indigo-500 text-white' : 'border-slate-300 bg-white/40'
                          }`}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <h5 className="text-[12px] font-black leading-tight text-slate-850">
                            {opt.label.split(' ').slice(1).join(' ')}
                          </h5>
                          <p className="text-[10px] text-slate-505 font-bold mt-1 leading-snug">
                            {opt.desc}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Part 2 Custom input */}
                <div className="pt-2 border-t border-dashed border-indigo-200/20">
                  <label className="block text-[10px] font-black text-slate-550 uppercase tracking-widest mb-1.5">
                    ✍️ Or add custom marketing channels:
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="input-custom-promo-channel"
                      type="text"
                      value={newCustomPromoChannel}
                      onChange={(e) => setNewCustomPromoChannel(e.target.value)}
                      placeholder="e.g. Grandma's local gardening newsletter, library corkboard..."
                      className="flex-1 glass-input focus:bg-white/90 focus:border-indigo-400 rounded-xl px-4 py-2 text-xs font-semibold outline-hidden text-slate-800"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddCustomPromoChannel()}
                    />
                    <button
                      id="btn-add-custom-promo-channel"
                      type="button"
                      onClick={handleAddCustomPromoChannel}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs px-4 rounded-xl flex items-center gap-1 active:scale-95 transition-all shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" /> Add
                    </button>
                  </div>

                  {/* Display Part 2 custom tags */}
                  <div className="flex flex-wrap gap-2 mt-3.5">
                    {(formData.promoChannels || []).filter(c => !promoChannelOptions.some(opt => opt.label === c)).length === 0 ? (
                      <p className="text-[11px] text-slate-405 font-semibold italic">No custom marketing channels added yet.</p>
                    ) : (
                      (formData.promoChannels || []).filter(c => !promoChannelOptions.some(opt => opt.label === c)).map((channel, idx) => (
                        <span
                          key={idx}
                          className="bg-white/85 text-indigo-900 border border-indigo-300/30 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs"
                        >
                          <Check className="w-3.5 h-3.5 text-indigo-600" />
                          {channel}
                          <button
                            id={`btn-remove-custom-promo-channel-${idx}`}
                            onClick={() => {
                              const currentChannels = formData.promoChannels || [];
                              const updated = {
                                ...formData,
                                promoChannels: currentChannels.filter((c) => c !== channel),
                              };
                              updateData(updated);
                            }}
                            className="hover:text-rose-500 ml-1 font-extrabold text-xs cursor-pointer"
                          >
                            ×
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Finish master strategy button */}
            <div className="flex justify-between items-center border-t border-indigo-200/40 pt-5 mt-8">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase">Step 4 of 4 completed</span>
              <button
                id="btn-4ps-done"
                onClick={onNext}
                className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 font-extrabold text-sm text-white px-6 py-3 rounded-2xl flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer animate-pulse"
              >
                Complete Master 4Ps Blueprint! 🏆
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { PositioningMadLibs, PresetBusiness } from '../types';
import { Landmark, Sparkles, Send, RefreshCw, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PositioningModuleProps {
  initialData: PositioningMadLibs;
  preset: PresetBusiness | undefined;
  onSave: (data: PositioningMadLibs) => void;
  onNext: () => void;
  heroName: string; // Feed from first step for personalized text!
}

export default function PositioningModule({
  initialData,
  preset,
  onSave,
  onNext,
  heroName,
}: PositioningModuleProps) {
  const [formData, setFormData] = useState<PositioningMadLibs>({ ...initialData });
  const [flashMessage, setFlashMessage] = useState(false);

  const handleApplyPreset = () => {
    if (preset?.suggestedPositioning) {
      const suggested = preset.suggestedPositioning;
      const updated = {
        targetHero: suggested.targetHero || '',
        problem: suggested.problem || '',
        competitor: suggested.competitor || '',
        uniqueFeature: suggested.uniqueFeature || '',
        brandValue: suggested.brandValue || '',
      };
      setFormData(updated);
      onSave(updated);
      setFlashMessage(true);
      setTimeout(() => setFlashMessage(false), 2000);
    }
  };

  const handleFieldChange = (field: keyof PositioningMadLibs, value: string) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    onSave(updated); // Sync with local storage
  };

  // Check if complete
  const isFormComplete = () => {
    return (
      formData.targetHero.trim().length > 2 &&
      formData.problem.trim().length > 2 &&
      formData.competitor.trim().length > 2 &&
      formData.uniqueFeature.trim().length > 2 &&
      formData.brandValue.trim().length > 2
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Interactive Mad Libs Forms */}
      <div className="lg:col-span-7 glass-card rounded-3xl border border-white/65 p-6 shadow-md relative z-10">
        <div>
          <span className="text-[10px] font-black text-amber-700 bg-amber-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider border border-amber-500/10">
            Practice 2: Brand Positioning
          </span>
          <h3 className="text-2xl font-extrabold text-slate-850 mt-2 flex items-center gap-2 font-display">
            <Landmark className="w-5.5 h-5.5 text-yellow-600" />
            The Positioning Mad Libs Game
          </h3>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
            Positioning is telling the world how your product is completely different and{' '}
            <strong>ten times cooler</strong> than what already exists. Let's fill in the blanks
            of the "Ultimate Startup Formula" below!
          </p>
        </div>

        {/* Suggestion alert drawer */}
        {preset?.suggestedPositioning && (
          <div className="bg-amber-550/5 border border-amber-300/40 rounded-2xl p-4 my-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <p className="text-xs font-black text-amber-950 flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-amber-500" /> Need a positioning trigger?
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5 font-bold">
                We can load a smart positioning setup built precisely for a{' '}
                <strong>{preset.title}</strong> competitor matchup.
              </p>
            </div>
            <button
              id="btn-apply-pos-preset"
              onClick={handleApplyPreset}
              className="bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-black text-xs px-3.5 py-2 rounded-xl transition-all shadow-sm shrink-0 cursor-pointer"
            >
              Autofill Mad Libs 🪄
            </button>
          </div>
        )}

        {/* Visual Game Fill Sheets */}
        <div className="bg-white/20 border border-white/35 rounded-2xl p-5 md:p-6 space-y-5 shadow-xs mt-4">
          <p className="text-[10px] font-black text-indigo-700 bg-indigo-500/5 px-2.5 py-0.5 rounded-full inline-block tracking-wider uppercase">
            FILL IN THE BLANKS:
          </p>

          <div className="space-y-4 text-xs md:text-sm font-semibold text-slate-800 leading-relaxed">
            {/* Target blank */}
            <div className="flex flex-col gap-1">
              <span>
                "Our business is designed for (example:{' '}
                <span className="text-indigo-600 font-extrabold">{heroName || 'skating fans'}</span> or{' '}
                <span className="italic">our Target Hero category</span>)
              </span>
              <input
                id="pos-target-hero"
                type="text"
                value={formData.targetHero}
                onChange={(e) => handleFieldChange('targetHero', e.target.value)}
                placeholder="e.g. eco-friendly teen skateboarders"
                className="glass-input focus:bg-white/90 focus:border-yellow-500 rounded-xl px-3 py-1.5 font-extrabold outline-hidden text-slate-850 mt-1"
              />
            </div>

            {/* Problem blank */}
            <div className="flex flex-col gap-1">
              <span>who are tired of and struggle with (the customer problem):</span>
              <input
                id="pos-problem"
                type="text"
                value={formData.problem}
                onChange={(e) => handleFieldChange('problem', e.target.value)}
                placeholder="e.g. paying hundreds for boards made from cut timber trees"
                className="glass-input focus:bg-white/90 focus:border-yellow-500 rounded-xl px-3 py-1.5 font-extrabold outline-hidden text-slate-850 mt-1"
              />
            </div>

            {/* Competitor blank */}
            <div className="flex flex-col gap-1">
              <span>Unlike the main classic competitor, which is:</span>
              <input
                id="pos-competitor"
                type="text"
                value={formData.competitor}
                onChange={(e) => handleFieldChange('competitor', e.target.value)}
                placeholder="e.g. standard store wooden plastic board brands"
                className="glass-input focus:bg-white/90 focus:border-yellow-500 rounded-xl px-3 py-1.5 font-extrabold outline-hidden text-slate-850 mt-1"
              />
            </div>

            {/* Unique feature blank */}
            <div className="flex flex-col gap-1">
              <span>Our brand provides the amazing unique feature:</span>
              <input
                id="pos-unique-feature"
                type="text"
                value={formData.uniqueFeature}
                onChange={(e) => handleFieldChange('uniqueFeature', e.target.value)}
                placeholder="e.g. unbreakable boards recycled 100% from ocean fishing nets"
                className="glass-input focus:bg-white/90 focus:border-yellow-500 rounded-xl px-3 py-1.5 font-extrabold outline-hidden text-slate-850 mt-1"
              />
            </div>

            {/* Brand Value blank */}
            <div className="flex flex-col gap-1">
              <span>because we strongly believe (our brand value/mission):</span>
              <input
                id="pos-brand-value"
                type="text"
                value={formData.brandValue}
                onChange={(e) => handleFieldChange('brandValue', e.target.value)}
                placeholder="e.g. skateparks should protect sea life, not pollute it"
                className="glass-input focus:bg-white/90 focus:border-yellow-500 rounded-xl px-3 py-1.5 font-extrabold outline-hidden text-slate-850 mt-1"
              />
              <span>."</span>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end gap-3 border-t border-indigo-200/40 pt-5 mt-6">
          <button
            id="btn-save-positioning"
            onClick={onNext}
            disabled={!isFormComplete()}
            className={`w-full sm:w-auto font-black text-sm px-6 py-3 rounded-2xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer ${
              isFormComplete()
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-slate-950'
                : 'bg-white/30 text-slate-400 cursor-not-allowed border border-white/25'
            }`}
          >
            Lock-In Positioning Statement 🎯
          </button>
        </div>
      </div>

      {/* Visual Neon Billboard Rendering */}
      <div className="lg:col-span-5 flex flex-col gap-6 relative z-10">
        <div className="bg-slate-950/80 backdrop-blur-md text-white rounded-3xl p-6 border border-white/10 shadow-xl flex flex-col justify-between min-h-[420px]">
          <div>
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
              <span className="text-[10px] font-bold text-yellow-400 uppercase tracking-widest">
                💡 Neon Brand Billboard
              </span>
              <span className="text-[10px] text-slate-500 font-mono">BILLBOARD_EMULATOR_07</span>
            </div>

            {/* Simulated Live Glowing text */}
            <div className="space-y-4">
              {!isFormComplete() && (
                <div className="py-12 text-center text-slate-600 border border-dashed border-slate-800 rounded-2xl">
                  <RefreshCw className="w-8 h-8 text-slate-700 animate-spin mx-auto mb-3" />
                  <p className="text-xs font-bold font-mono">WAITING_FOR_SENSORY_DATA</p>
                  <p className="text-[10px] mt-1 text-slate-500 max-w-[200px] mx-auto">
                    Fill in all blanks on the worksheet to illuminate this neon billboard!
                  </p>
                </div>
              )}

              {isFormComplete() && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="font-sans leading-relaxed tracking-wide text-slate-200 text-sm md:text-base space-y-4"
                >
                  <p>
                    "Our business is designed for{' '}
                    <span className="text-yellow-400 font-extrabold underline decoration-yellow-400/40 bg-yellow-400/5 px-2 py-0.5 rounded-lg whitespace-normal inline-block">
                      {formData.targetHero}
                    </span>{' '}
                    who are tired of and struggle with{' '}
                    <span className="text-indigo-400 font-bold bg-indigo-400/5 px-2 py-0.5 rounded-lg whitespace-normal inline-block">
                      {formData.problem}
                    </span>
                    ."
                  </p>

                  <p>
                    "Unlike{' '}
                    <span className="text-pink-400 font-bold bg-pink-400/5 px-2 py-0.5 rounded-lg whitespace-normal inline-block">
                      {formData.competitor}
                    </span>
                    , we provide{' '}
                    <span className="text-emerald-400 font-extrabold bg-emerald-400/5 px-2 py-0.5 rounded-lg whitespace-normal inline-block">
                      {formData.uniqueFeature}
                    </span>{' '}
                    because we strongly believe that{' '}
                    <span className="text-cyan-400 font-bold bg-cyan-400/5 px-2 py-0.5 rounded-lg whitespace-normal inline-block">
                      {formData.brandValue}
                    </span>
                    ."
                  </p>
                </motion.div>
              )}
            </div>
          </div>

          <div className="border-t border-slate-800 pt-4 mt-6">
            <div className="flex items-center gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800/40">
              <Award className="w-7 h-7 text-yellow-400 animate-pulse shrink-0" />
              <div>
                <h5 className="text-[10px] text-yellow-400 font-bold uppercase tracking-wider leading-none">
                  Competition Worthy Bonus
                </h5>
                <p className="text-[10px] text-slate-400 leading-tight mt-1 font-medium">
                  {isFormComplete()
                    ? "Perfect positioning draft! Judges love when you clearly state WHO your customer is and WHAT makes your model unique."
                    : "Fill out the blanks to find your secret formula. This helps judges remember your business name above others!"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {flashMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 border border-slate-800 z-50 pointer-events-none"
          >
            <Sparkles className="w-5 h-5 text-yellow-400" />
            <span className="text-xs font-bold">🎯 Smart Positioning Formula applied!</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { TargetHero, PresetBusiness } from '../types';
import { UserCheck, Sparkles, Smile, MessageCircle, Heart, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TargetHeroProps {
  initialData: TargetHero;
  preset: PresetBusiness | undefined;
  onSave: (data: TargetHero) => void;
  onNext: () => void;
}

export default function TargetHeroModule({
  initialData,
  preset,
  onSave,
  onNext,
}: TargetHeroProps) {
  const [formData, setFormData] = useState<TargetHero>({ ...initialData });
  const [showHelper, setShowHelper] = useState(false);

  // Auto-load template helper guide if empty
  useEffect(() => {
    if (!formData.heroName && !formData.heroHobby && preset?.suggestedSegment) {
      // Don't auto-overwrite, but make preset options clickable
    }
  }, [preset, formData]);

  const handleApplyPresetSegment = () => {
    if (preset?.suggestedSegment) {
      const suggested = preset.suggestedSegment;
      const updated = {
        heroName: suggested.heroName || '',
        heroAge: suggested.heroAge || 12,
        heroHobby: suggested.heroHobby || '',
        heroPainPoint: suggested.heroPainPoint || '',
        heroHangout: suggested.heroHangout || '',
      };
      setFormData(updated);
      onSave(updated);
      setShowHelper(true);
      setTimeout(() => setShowHelper(false), 2000);
    }
  };

  const handleFieldChange = (field: keyof TargetHero, value: string | number) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    onSave(updated); // Sync data on change
  };

  // Calculate matching target rating
  const calculateCompleteness = () => {
    let score = 0;
    if (formData.heroName.length > 2) score += 20;
    if (formData.heroAge >= 9 && formData.heroAge <= 16) score += 20;
    if (formData.heroHobby.length > 5) score += 20;
    if (formData.heroPainPoint.length > 8) score += 20;
    if (formData.heroHangout.length > 4) score += 20;
    return score;
  };

  const score = calculateCompleteness();
  let scoreText = 'Detective Intern 🔍';
  let scoreColor = 'bg-slate-200 text-slate-700';
  if (score === 100) {
    scoreText = 'Master Profiler 👑';
    scoreColor = 'bg-emerald-500 text-white';
  } else if (score >= 60) {
    scoreText = 'Super Segmenter ⚡';
    scoreColor = 'bg-indigo-500 text-white';
  } else if (score >= 20) {
    scoreText = 'Junior Scout 🌱';
    scoreColor = 'bg-amber-500 text-white';
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Worksheet Inputs */}
      <div className="lg:col-span-7 glass-card rounded-3xl border border-white/65 p-6 shadow-md relative z-10">
        <div className="flex justify-between items-start mb-6">
          <div>
            <span className="text-[10px] font-black text-indigo-700 bg-indigo-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider border border-indigo-500/10">
              Practice 1: Target Market
            </span>
            <h3 className="text-2xl font-extrabold text-slate-850 mt-2 flex items-center gap-2 font-display">
              <UserCheck className="w-6 h-6 text-indigo-600" />
              Build a "Target Hero" Profile
            </h3>
            <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed">
              You cannot sell your product to "everyone on Earth!" Let's focus on one specific person
              who will absolutely <strong>love</strong> your product. We call them your "Target Hero."
            </p>
          </div>
        </div>

        {/* Preset suggestion chip */}
        {preset?.suggestedSegment && (
          <div className="bg-amber-500/5 border border-amber-300/40 rounded-2xl p-4 mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <p className="text-xs font-black text-amber-900 flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-amber-500 animate-spin" /> Need a training wheel suggestion?
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5 font-semibold">
                We can load a smart starting Target Hero tailored to your{' '}
                <strong>{preset.title}</strong> plan.
              </p>
            </div>
            <button
              id="btn-apply-suggestion"
              onClick={handleApplyPresetSegment}
              className="bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-black text-xs px-3.5 py-2 rounded-xl transition-all shadow-sm cursor-pointer"
            >
              Autofill My Hero 🪄
            </button>
          </div>
        )}

        <div className="space-y-4">
          {/* Question 1: Name */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              1. What is your Target Hero's Name? (Give them a catchy name!)
            </label>
            <input
              id="input-hero-name"
              type="text"
              value={formData.heroName}
              onChange={(e) => handleFieldChange('heroName', e.target.value)}
              placeholder="e.g. Skater Stella or Gaming Gabe"
              className="w-full glass-input focus:bg-white/85 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden transition-all text-slate-850"
            />
          </div>

          {/* Question 2: Age with visual slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                2. How old are they? (Choose between 8 to 18 years old)
              </label>
              <span className="text-xs font-black text-indigo-700 bg-white border border-indigo-100 px-2.5 py-1 rounded-lg">
                {formData.heroAge} years old
              </span>
            </div>
            <input
              id="input-hero-age"
              type="range"
              min="8"
              max="18"
              value={formData.heroAge}
              onChange={(e) => handleFieldChange('heroAge', parseInt(e.target.value))}
              className="w-full accent-indigo-500 h-2 bg-white rounded-full cursor-pointer border border-slate-200"
            />
          </div>

          {/* Question 3: Hobby */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              3. What is their favorite hobby? (What makes them smile?)
            </label>
            <input
              id="input-hero-hobby"
              type="text"
              value={formData.heroHobby}
              onChange={(e) => handleFieldChange('heroHobby', e.target.value)}
              placeholder="e.g. Recording TikTok dances, practicing ollies, playing Roblox with pals"
              className="w-full glass-input focus:bg-white/85 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden transition-all text-slate-850"
            />
          </div>

          {/* Question 4: Pain Point */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              4. What is their biggest struggle or super-annoyance? (Your secret business target!)
            </label>
            <textarea
              id="input-hero-painpoint"
              rows={2}
              value={formData.heroPainPoint}
              onChange={(e) => handleFieldChange('heroPainPoint', e.target.value)}
              placeholder="e.g. Their phone battery always dies during soccer practice, or they want cool shoes but skate brands are too expensive"
              className="w-full glass-input focus:bg-white/85 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden transition-all text-slate-850 resize-none"
            />
          </div>

          {/* Question 5: Hangout Spot */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              5. Where do they spend most of their free time? (So we can advertise there!)
            </label>
            <input
              id="input-hero-hangout"
              type="text"
              value={formData.heroHangout}
              onChange={(e) => handleFieldChange('heroHangout', e.target.value)}
              placeholder="e.g. YouTube shorts, the school local outdoor basketball park, family game nights"
              className="w-full glass-input focus:bg-white/85 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden transition-all text-slate-850"
            />
          </div>
        </div>

        {/* Done / lock in button */}
        <div className="flex justify-end gap-3 border-t border-indigo-200/40 pt-5 mt-6">
          <button
            id="btn-save-hero"
            onClick={onNext}
            disabled={score < 40}
            className={`w-full sm:w-auto font-black text-sm px-6 py-3 rounded-2xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer ${
              score >= 40
                ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white'
                : 'bg-white/30 text-slate-400 cursor-not-allowed border border-white/20'
            }`}
          >
            Lock-In Target Hero Profile 🏆
          </button>
        </div>
      </div>

      {/* Hero Card Visual Board */}
      <div className="lg:col-span-5 flex flex-col gap-6 relative z-10">
        {/* Profile completeness status widget */}
        <div className="bg-slate-950/80 backdrop-blur-md text-white rounded-3xl p-5 border border-white/10 shadow-md">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-mono">
              Profile Match Level
            </span>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${scoreColor} shadow-sm uppercase font-mono`}>
              {scoreText}
            </span>
          </div>
          <div className="h-3 bg-white/10 rounded-full overflow-hidden mt-3 p-0.5">
            <div
              className="bg-linear-to-r from-pink-500 through-purple-500 to-indigo-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${score}%` }}
            />
          </div>
          <p className="text-xs text-slate-400 mt-2.5 leading-relaxed font-bold">
            {score === 100
              ? 'Awesome job! You have filled out every crucial piece to know your hero perfectly.'
              : score >= 60
              ? 'Excellent progress! Your profile allows you to design a great strategy.'
              : 'Keep writing details! Specific details about your Hero make your marketing much more effective.'}
          </p>
        </div>

        {/* Display The Interactive Hero ID card */}
        <div className="relative bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 rounded-3xl p-[1.5px] shadow-lg overflow-hidden">
          {/* Neon scan-line glow border effect */}
          <div className="absolute top-0 left-0 w-full h-1.5 bg-white/20 animate-pulse" />

          <div className="bg-slate-950/70 backdrop-blur-lg text-white p-5 md:p-6 rounded-[22px] min-h-[380px] flex flex-col justify-between">
            {/* Header of the ID Card */}
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div>
                <span className="text-[9px] font-bold tracking-widest text-indigo-400 uppercase block font-mono">
                  CUST_TARGET_SYSTEM_v1.0
                </span>
                <span className="text-sm font-black text-white tracking-tight uppercase font-display">
                  Target Hero Dossier
                </span>
              </div>
              <div className="bg-indigo-500/20 text-indigo-300 font-bold text-[10px] uppercase border border-indigo-500/30 px-2 py-0.5 rounded-md font-mono">
                Verified Customer
              </div>
            </div>

            {/* Profile body content */}
            <div className="my-5 flex flex-col sm:flex-row gap-5 items-center sm:items-start text-center sm:text-left">
              {/* Dynamic Avatar box based on inputs */}
              <div className="relative group">
                <div className="w-20 h-20 bg-linear-to-br from-indigo-500/40 to-pink-500/40 rounded-2xl border border-white/20 flex flex-col items-center justify-center p-1 overflow-hidden">
                  {formData.heroName ? (
                    <div className="text-4xl text-center">
                      {formData.heroAge <= 11 ? '👦' : formData.heroAge <= 14 ? '🧑' : '👨'}
                    </div>
                  ) : (
                    <div className="text-3xl text-slate-500 animate-pulse">👤</div>
                  )}
                </div>
                {/* Visual camera overlay marker */}
                <div className="absolute -bottom-1 -right-1 bg-indigo-500 text-white px-2 py-0.5 rounded-full text-[8px] font-black uppercase text-center border border-slate-950">
                  ID
                </div>
              </div>

              {/* Data listing of the customer */}
              <div className="flex-1 space-y-3">
                <div>
                  <h4 className="text-[9px] text-slate-500 font-bold uppercase tracking-widest m-0 font-mono">Name</h4>
                  <p className="text-lg font-extrabold text-white mt-0.5 font-display">
                    {formData.heroName || <span className="text-slate-700 italic">Insert catchy name...</span>}
                  </p>
                </div>

                <div>
                  <h4 className="text-[9px] text-slate-500 font-bold uppercase tracking-widest m-0 font-mono">Age Group</h4>
                  <p className="text-sm font-bold text-indigo-200 mt-0.5">
                    {formData.heroAge} years old (Tweens / Generation Alpha)
                  </p>
                </div>

                <div>
                  <h4 className="text-[9px] text-slate-500 font-bold uppercase tracking-widest m-0 font-mono">Favorite Hobby</h4>
                  <p className="text-xs font-semibold text-pink-200 leading-tight mt-0.5">
                    {formData.heroHobby || <span className="text-slate-700 italic">Enter cool pastime...</span>}
                  </p>
                </div>
              </div>
            </div>

            {/* Pain Point card banner */}
            <div className="space-y-3.5 pt-3 border-t border-white/10">
              <div className="bg-slate-900/60 border border-white/5 rounded-xl p-3">
                <h5 className="text-[9px] text-rose-400 font-bold uppercase tracking-widest flex items-center gap-1 font-mono">
                  <Heart className="w-3.5 h-3.5 fill-rose-400" />
                  Primary Struggle Points
                </h5>
                <p className="text-xs text-slate-300 leading-relaxed font-semibold mt-1">
                  {formData.heroPainPoint || (
                    <span className="text-slate-600 italic">What is their main daily hassle or trouble? Enter left...</span>
                  )}
                </p>
              </div>

              <div className="flex items-center gap-2 bg-indigo-950/40 border border-white/5 rounded-xl p-2.5">
                <Search className="w-3.5 h-3.5 text-indigo-300 shrink-0" />
                <div className="min-w-0">
                  <h5 className="text-[9px] text-indigo-400 font-bold uppercase tracking-wider leading-none m-0 font-mono">
                    Advertising Lounge Hangout
                  </h5>
                  <p className="text-[11px] text-indigo-200 truncate font-bold mt-0.5">
                    {formData.heroHangout || <span className="text-slate-600 italic">Where do we post?</span>}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <AnimatePresence>
        {showHelper && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 border border-slate-800 z-50 pointer-events-none"
          >
            <Sparkles className="w-5 h-5 text-amber-400 animate-spin" />
            <span className="text-xs font-bold">🪄 Suggestions Loaded into Workspace Card!</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

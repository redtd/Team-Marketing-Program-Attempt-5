import React from 'react';
import { BADGES } from '../data';
import { Award, Trophy, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface ProgressProps {
  completedSteps: string[];
  productTitle: string;
  presetEmoji: string;
  onGoToStep: (step: string) => void;
  activeStep: string;
}

export default function ProgressDashboard({
  completedSteps,
  productTitle,
  presetEmoji,
  onGoToStep,
  activeStep,
}: ProgressProps) {
  const stepsList = [
    { key: 'setup', label: '1. Build Idea' },
    { key: 'segmentation', label: '2. Select Hero' },
    { key: 'positioning', label: '3. Find Secret' },
    { key: 'product', label: '4. Product (P1)' },
    { key: 'pricing', label: '5. Price (P2)' },
    { key: 'place', label: '6. Place (P3)' },
    { key: 'promotion', label: '7. Promo (P4)' },
    { key: 'poster', label: '8. Poster ✨' },
  ];

  // Calculate Rank
  const doneCount = completedSteps.filter(s => s !== 'setup').length || 0;
  let rank = '🟢 Marketing Novice';
  let levelColor = 'text-emerald-500 bg-emerald-50';
  let badgeBorder = 'border-emerald-200';

  if (doneCount >= 5) {
    rank = '👑 Chief Marketing Officer (CMO)';
    levelColor = 'text-amber-600 bg-amber-50 font-bold';
    badgeBorder = 'border-amber-300';
  } else if (doneCount >= 3) {
    rank = '⚡ Strategy Specialist';
    levelColor = 'text-cyan-600 bg-cyan-50';
    badgeBorder = 'border-cyan-200';
  } else if (doneCount >= 1) {
    rank = '🎨 Creative Consultant';
    levelColor = 'text-purple-600 bg-purple-50';
    badgeBorder = 'border-purple-200';
  }

  const progressPercent = Math.round((completedSteps.length / stepsList.length) * 100);

  return (
    <div className="glass-card rounded-3xl border border-white/60 shadow-xl p-5 md:p-6 mb-8 transition-all duration-300">
      {/* Upper metrics */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-dashed border-indigo-200/40 pb-5">
        <div>
          <span className="text-[10px] font-black uppercase tracking-widest text-[#4f46e5]/70 bg-indigo-500/10 px-2 py-0.5 rounded-md">ACTIVE CAMPAIGN</span>
          <h2 className="text-xl md:text-2xl font-extrabold text-slate-850 flex items-center gap-2 mt-1.5 font-display">
            <span role="img" aria-label="Product logo" className="text-2xl bounce-animation">{presetEmoji || '💼'}</span>
            {productTitle || 'Untamed Starter Idea'}
          </h2>
        </div>

        {/* Level Rank Badge */}
        <div className={`px-4 py-2 rounded-2xl border ${badgeBorder} ${levelColor} flex items-center gap-2 text-xs md:text-sm shadow-sm font-bold hover:scale-105 transition-transform`}>
          <Trophy className="w-4 h-4" />
          <span>Rank: {rank}</span>
          <Sparkles className="w-3.5 h-3.5 animate-pulse text-amber-500" />
        </div>
      </div>

      {/* Steps Progress Map */}
      <div className="mt-5">
        <div className="flex justify-between items-center mb-2.5">
          <div className="flex items-center gap-1.5">
            <Award className="w-5 h-5 text-indigo-500" />
            <span className="text-sm font-extrabold text-slate-700">Adventure Map Progress:</span>
          </div>
          <span className="text-sm font-black text-indigo-700 bg-white/80 border border-indigo-100 px-2.5 py-0.5 rounded-full shadow-xs">{progressPercent}%</span>
        </div>

        <div className="w-full bg-white/30 border border-white/40 h-3.5 rounded-full overflow-hidden mb-5 p-0.5">
          <motion.div
            className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        {/* Step Links Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {stepsList.map((step) => {
            const isCompleted = completedSteps.includes(step.key);
            const isActive = activeStep === step.key;

            return (
              <button
                key={step.key}
                id={`btn-step-${step.key}`}
                onClick={() => onGoToStep(step.key)}
                className={`relative py-2.5 px-3 rounded-xl text-[11px] font-black text-center border transition-all overflow-hidden cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm transform scale-[1.03]'
                    : isCompleted
                    ? 'bg-white/70 border-indigo-200 text-indigo-700 hover:bg-white/95'
                    : 'bg-white/20 border-white/30 text-slate-500 hover:bg-white/40'
                }`}
              >
                {/* Visual marker */}
                {isCompleted && !isActive && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                )}
                {step.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Collectible Badges Rack */}
      <div className="mt-6 border-t border-indigo-200/40 pt-5">
        <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
          🏆 COLLECTIBLE STAR BADGES ({completedSteps.filter(s => s !== 'setup').length - 1 < 0 ? 0 : completedSteps.filter(s => s !== 'setup').length - 1} / 5 unlocked)
        </h3>
        <div className="flex flex-wrap gap-4">
          {BADGES.map((b) => {
            const isUnlocked = completedSteps.includes(b.unlockedBy);

            return (
              <div
                key={b.id}
                id={`badge-card-${b.id}`}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl border transition-all duration-300 max-w-sm ${
                  isUnlocked
                    ? 'bg-white/80 border-amber-200 text-amber-950 shadow-sm scale-100'
                    : 'bg-white/25 border-white/20 text-slate-400 opacity-60'
                }`}
              >
                <div
                  className={`text-2xl p-1 rounded-xl flex items-center justify-center ${
                    isUnlocked ? 'bg-amber-100 border border-amber-200 animate-bounce' : 'bg-white/20 border border-white/10 grayscale'
                  }`}
                >
                  {b.emoji}
                </div>
                <div className="flex-1 min-w-[120px]">
                  <p className={`text-xs font-black ${isUnlocked ? 'text-amber-800' : 'text-slate-500'}`}>
                    {b.title}
                  </p>
                  <p className="text-[10px] leading-tight text-slate-400 font-bold">
                    {isUnlocked ? b.description : `Complete step to unlock!`}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { MarketingPlanState, PresetBusiness, TargetHero, PositioningMadLibs, FourPsState } from './types';
import { PRESETS, ALL_STEP_KEYS } from './data';
import ProgressDashboard from './components/ProgressDashboard';
import TargetHeroModule from './components/TargetHeroModule';
import PositioningModule from './components/PositioningModule';
import FourPsModule from './components/FourPsModule';
import FinalPoster from './components/FinalPoster';
import { Sparkles, Trophy, Lightbulb, Compass, Rocket, Smile, AlertCircle, ArrowRight, BookOpen, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const LOCAL_STORAGE_KEY = 'launchpad_teen_marketing_plan_v1';

const INITIAL_EMPTY_STATE: MarketingPlanState = {
  id: 'current_session_plan',
  presetKey: '',
  productTitle: '',
  productDescription: '',
  segmentation: {
    heroName: '',
    heroAge: 12,
    heroHobby: '',
    heroPainPoint: '',
    heroHangout: '',
  },
  positioning: {
    targetHero: '',
    problem: '',
    competitor: '',
    uniqueFeature: '',
    brandValue: '',
  },
  fourPs: {
    productFeatures: [],
    productPackaging: '',
    costToMake: 1.0,
    sellingPrice: 3.5,
    placesToSell: [],
    promoStrategies: [],
    promoChannels: [],
  },
  completedSteps: ['setup'],
};

export default function App() {
  const [activeStep, setActiveStep] = useState<string>('setup');
  const [planState, setPlanState] = useState<MarketingPlanState>(INITIAL_EMPTY_STATE);
  const [customTitle, setCustomTitle] = useState('');
  const [customDesc, setCustomDesc] = useState('');
  const [customCategory, setCustomCategory] = useState('My Original Idea');
  const [activePreset, setActivePreset] = useState<PresetBusiness | undefined>(undefined);

  // Load state from local storage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as MarketingPlanState;
        setPlanState(parsed);
        if (parsed.presetKey) {
          const match = PRESETS.find((p) => p.key === parsed.presetKey);
          setActivePreset(match);
        }
        // Restore step
        if (parsed.completedSteps.length > 1) {
          // Send them to the last done, or poster if everything completed
          const lastIndex = parsed.completedSteps.length - 1;
          const targetStep = parsed.completedSteps[lastIndex];
          setActiveStep(targetStep);
        } else {
          setActiveStep('setup');
        }
      }
    } catch (e) {
      console.warn('Error reloading previous plan state', e);
    }
  }, []);

  // Save changes to local storage helper
  const handleSaveState = (updated: MarketingPlanState) => {
    setPlanState(updated);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
  };

  // Launch a new session
  const handleSelectPreset = (preset: PresetBusiness) => {
    const initialized: MarketingPlanState = {
      id: 'current_session_plan',
      presetKey: preset.key,
      productTitle: preset.title,
      productDescription: preset.description,
      segmentation: {
        heroName: '',
        heroAge: 12,
        heroHobby: '',
        heroPainPoint: '',
        heroHangout: '',
      },
      positioning: {
        targetHero: '',
        problem: '',
        competitor: '',
        uniqueFeature: '',
        brandValue: '',
      },
      fourPs: {
        productFeatures: [],
        productPackaging: '',
        costToMake: preset.suggestedFourPs.costToMake || 1.5,
        sellingPrice: preset.suggestedFourPs.sellingPrice || 4.5,
        placesToSell: [],
        promoStrategies: [],
        promoChannels: [],
      },
      completedSteps: ['setup', 'segmentation'],
    };

    setActivePreset(preset);
    handleSaveState(initialized);
    setActiveStep('segmentation');
  };

  // Launch a custom business session
  const handleLaunchCustomIdea = () => {
    if (!customTitle.trim()) return;

    const customPlan: MarketingPlanState = {
      id: 'current_session_plan',
      presetKey: 'custom',
      productTitle: customTitle.trim(),
      productDescription: customDesc.trim() || 'A spectacular new teen-led product idea waiting to conquer the market!',
      segmentation: {
        heroName: '',
        heroAge: 12,
        heroHobby: '',
        heroPainPoint: '',
        heroHangout: '',
      },
      positioning: {
        targetHero: '',
        problem: '',
        competitor: '',
        uniqueFeature: '',
        brandValue: '',
      },
      fourPs: {
        productFeatures: [],
        productPackaging: '',
        costToMake: 2.0,
        sellingPrice: 5.0,
        placesToSell: [],
        promoStrategies: [],
        promoChannels: [],
      },
      completedSteps: ['setup', 'segmentation'],
    };

    setActivePreset(undefined);
    handleSaveState(customPlan);
    setActiveStep('segmentation');
  };

  // Individual step saver proxies
  const handleSaveSegmentation = (data: TargetHero) => {
    const updated = { ...planState, segmentation: data };
    handleSaveState(updated);
  };

  const handleSavePositioning = (data: PositioningMadLibs) => {
    const updated = { ...planState, positioning: data };
    handleSaveState(updated);
  };

  const handleSaveFourPs = (data: FourPsState) => {
    const updated = { ...planState, fourPs: data };
    handleSaveState(updated);
  };

  // Step locking transition
  const handleCommitStep = (completedStepKey: string, nextStepKey: string) => {
    // Merge step into completed array if missing
    let completed = [...planState.completedSteps];
    if (!completed.includes(completedStepKey)) {
      completed.push(completedStepKey);
    }
    // Auto-advance
    if (!completed.includes(nextStepKey)) {
      completed.push(nextStepKey);
    }

    const updated = {
      ...planState,
      completedSteps: completed,
    };
    handleSaveState(updated);
    setActiveStep(nextStepKey);
  };

  // Nav mapping helpers
  const handleGoToStep = (stepKey: string) => {
    if (planState.completedSteps.includes(stepKey) || stepKey === 'setup') {
      setActiveStep(stepKey);
    }
  };

  const handleResetSession = () => {
    if (window.confirm('Do you want to reset and design a brand new marketing plan? This cleans current data.')) {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      setPlanState(INITIAL_EMPTY_STATE);
      setActivePreset(undefined);
      setCustomTitle('');
      setCustomDesc('');
      setActiveStep('setup');
    }
  };

  // Determine current Preset Emoji
  const getPresetEmoji = () => {
    if (activePreset) return activePreset.emoji;
    if (planState.presetKey === 'custom') return '🚀';
    return '💼';
  };

  return (
    <div className="min-h-screen bg-linear-to-br from-[#ebf4ff] via-[#fdf2f8] to-[#f5f3ff] text-slate-800 antialiased font-sans flex flex-col justify-between relative overflow-hidden">
      {/* Frosted Glass background blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-pink-300/20 blur-3xl animate-float-1" />
        <div className="absolute top-1/3 -right-20 w-80 h-80 rounded-full bg-indigo-300/15 blur-3xl animate-float-2" />
        <div className="absolute -bottom-20 left-1/4 w-96 h-96 rounded-full bg-violet-300/25 blur-3xl animate-float-3" />
      </div>

      {/* Visual Navigation Bar Header */}
      <header className="glass-nav py-4 px-6 sticky top-0 z-40 shadow-sm backdrop-blur-md relative">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
          <div className="flex items-center gap-2.5">
            <div className="bg-gradient-to-tr from-indigo-500 to-pink-500 text-white p-2 rounded-2xl shadow-md">
              <Rocket className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-slate-850 flex items-center gap-2 font-display">
                Launchpad
                <span className="text-[10px] font-black uppercase text-indigo-600 bg-white/70 border border-indigo-100 px-2 py-0.5 rounded-md">
                  Competition Edition
                </span>
              </h1>
              <p className="text-[10px] leading-none text-indigo-950/50 font-extrabold tracking-wider mt-0.5 uppercase">
                SMART CO-PILOT FOR YOUNG CREATIVE ENTREPRENEURS (11+ YEARS)
              </p>
            </div>
          </div>

          {activeStep !== 'setup' && (
            <button
              id="btn-header-reset"
              onClick={handleResetSession}
              className="bg-white/60 hover:bg-white/80 border border-white text-slate-600 font-bold text-xs px-3.5 py-1.8 rounded-xl transition-all shadow-xs hover:-translate-y-0.5 shrink-0"
            >
              Reset Current Workspace
            </button>
          )}
        </div>
      </header>

      {/* Main Container Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-5 md:p-8 relative z-10">
        {activeStep !== 'setup' && (
          <ProgressDashboard
            completedSteps={planState.completedSteps}
            productTitle={planState.productTitle}
            presetEmoji={getPresetEmoji()}
            onGoToStep={handleGoToStep}
            activeStep={activeStep}
          />
        )}

        <AnimatePresence mode="wait">
          {/* STEP: SETUP / ONBOARDING */}
          {activeStep === 'setup' && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-8"
            >
              {/* Educational Launch Banner */}
              <div className="bg-linear-to-br from-indigo-900 via-indigo-950 to-slate-950 rounded-3xl p-6 md:p-10 text-white relative overflow-hidden shadow-xl">
                <div className="absolute right-0 bottom-0 opacity-10 font-bold text-[180px] -rotate-12 pointer-events-none select-none">
                  BIZ
                </div>
                <div className="relative z-10 max-w-2xl space-y-4">
                  <div className="inline-flex items-center gap-2 bg-indigo-500/25 border border-indigo-400/20 text-indigo-300 font-extrabold text-xs px-3 py-1 rounded-full uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5" /> Fun, Simple 4Ps Guide
                  </div>
                  <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
                    Design a Winning Marketing Plan!
                  </h2>
                  <p className="text-xs md:text-base text-indigo-200 leading-relaxed font-semibold">
                    Preparing for a business competition or spelling out a school project? A great marketing
                    plan ensures classmates and judges fall in love with your idea. Let's learn
                    <strong> Market Segmentation, brand positioning, and the famous 4Ps formula </strong>
                    step-by-step through play!
                  </p>
                </div>
              </div>

              {/* Starter Presets Selector Grid */}
              <div className="space-y-4.5">
                <div className="flex items-center gap-2 border-b border-indigo-200/30 pb-2">
                  <BookOpen className="w-5.5 h-5.5 text-indigo-600" />
                  <h3 className="text-lg md:text-xl font-extrabold text-slate-850 font-display">
                    Option A: Choose a Cool Practice Startup Template
                  </h3>
                </div>
                <p className="text-xs text-indigo-950/60 leading-none font-medium">
                  No business idea yet? Pick one of our pre-designed, fun teenager starter ideas!
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-4">
                  {PRESETS.map((p) => (
                    <button
                      key={p.key}
                      id={`preset-card-${p.key}`}
                      onClick={() => handleSelectPreset(p)}
                      className="text-left glass-card hover:bg-white/60 border border-white/60 hover:border-indigo-400 rounded-3xl p-5 md:p-6 shadow-xs duration-300 transition-all hover:scale-[1.01] hover:shadow-md flex gap-4 items-start relative group outline-hidden"
                    >
                      <div className="text-4xl bg-white/80 backdrop-blur-md border border-white p-2.5 rounded-2xl group-hover:scale-110 transition-transform shrink-0 shadow-xs">
                        {p.emoji}
                      </div>
                      <div className="space-y-1.5">
                        <span className="text-[9px] font-extrabold uppercase text-indigo-700 bg-indigo-500/10 border border-indigo-500/10 px-2.5 py-0.5 rounded-full tracking-wider">
                          {p.category}
                        </span>
                        <h4 className="text-base font-black text-slate-850 group-hover:text-indigo-700 transition-colors font-display">
                          {p.title}
                        </h4>
                        <p className="text-xs text-slate-500 font-medium leading-relaxed">
                          {p.description}
                        </p>
                        <span className="text-[10px] font-extrabold text-indigo-600 flex items-center gap-1.5 mt-2.5">
                          Launch Blueprint Workout <ArrowRight className="w-3.5 h-3.5 animate-pulse" />
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Business Form Segment */}
              <div className="glass-card rounded-3xl p-6 md:p-8 shadow-sm border border-white/60 space-y-5">
                <div className="flex items-center gap-2 border-b border-indigo-200/30 pb-3">
                  <Compass className="w-5.5 h-5.5 text-indigo-600" />
                  <h3 className="text-lg md:text-xl font-extrabold text-slate-850 font-display">
                    Option B: Enter your own Original Business Idea
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1 font-medium">
                  Competing with an existing business proposal or custom school team project? Draft your secrets below!
                </p>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mt-4">
                  {/* Left input tags */}
                  <div className="md:col-span-8 space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                        Product Brand Name:
                      </label>
                      <input
                        id="input-custom-title"
                        type="text"
                        value={customTitle}
                        onChange={(e) => setCustomTitle(e.target.value)}
                        placeholder="e.g. Eco-Spark Bubble Tea, glow safety shoelaces..."
                        className="w-full glass-input focus:bg-white/80 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden transition-all text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                        Briefly list what makes it special (Elevator Pitch):
                      </label>
                      <textarea
                        id="input-custom-desc"
                        rows={3}
                        value={customDesc}
                        onChange={(e) => setCustomDesc(e.target.value)}
                        placeholder="e.g. Organic, non-plastic bubble teas served in custom-designed colorful water flasks that friends can reuse forever!"
                        className="w-full glass-input focus:bg-white/80 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden transition-all text-slate-800 resize-none"
                      />
                    </div>
                  </div>

                  {/* Sidebar quick assist tag info */}
                  <div className="md:col-span-4 bg-indigo-500/5 rounded-2xl p-4.5 border border-indigo-500/10 flex flex-col justify-between">
                    <div>
                      <h5 className="text-xs font-bold text-indigo-900 uppercase flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 text-indigo-500" /> Custom Builder Specs
                      </h5>
                      <p className="text-[11px] text-indigo-950/70 leading-relaxed font-semibold mt-2">
                        Enter your product name and unique concept pitch, and then click the rocket to lock-in your
                        workbook space.
                      </p>
                    </div>

                    <button
                      id="btn-custom-launch"
                      type="button"
                      disabled={!customTitle.trim()}
                      onClick={handleLaunchCustomIdea}
                      className={`w-full font-black text-xs py-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 ${
                        customTitle.trim()
                          ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white hover:scale-[1.02] cursor-pointer'
                          : 'bg-white/30 text-slate-400 cursor-not-allowed border border-white/20'
                      }`}
                    >
                      <Rocket className="w-4 h-4" /> Rocket Launch Idea!
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP: TARGET HERO MODULE */}
          {activeStep === 'segmentation' && (
            <motion.div
              key="segmentation"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <TargetHeroModule
                initialData={planState.segmentation}
                preset={activePreset}
                onSave={handleSaveSegmentation}
                onNext={() => handleCommitStep('segmentation', 'positioning')}
              />
            </motion.div>
          )}

          {/* STEP: BRAND POSITIONING */}
          {activeStep === 'positioning' && (
            <motion.div
              key="positioning"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <PositioningModule
                initialData={planState.positioning}
                preset={activePreset}
                onSave={handleSavePositioning}
                onNext={() => handleCommitStep('positioning', 'product')}
                heroName={planState.segmentation.heroName}
              />
            </motion.div>
          )}

          {/* STEPS FOR 4PS COMPILER (PRODUCT, PRICING, PLACE, PROMOTION) */}
          {['product', 'pricing', 'place', 'promotion'].includes(activeStep) && (
            <motion.div
              key="fourps"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <FourPsModule
                initialData={planState.fourPs}
                preset={activePreset}
                productTitle={planState.productTitle || activePreset?.title}
                productDescription={planState.productDescription || activePreset?.description}
                onSave={handleSaveFourPs}
                activeP={
                  activeStep === 'product'
                    ? 'product'
                    : activeStep === 'pricing'
                    ? 'pricing'
                    : activeStep === 'place'
                    ? 'place'
                    : 'promotion'
                }
                onGoToP={(p) => {
                  // Advance or step inside 4Ps limits
                  const nextKey =
                    p === 'product'
                      ? 'product'
                      : p === 'pricing'
                      ? 'pricing'
                      : p === 'place'
                      ? 'place'
                      : 'promotion';
                  setActiveStep(nextKey);
                }}
                onNext={() => {
                  // If on final promotion step, commit 4Ps and go to poster
                  if (activeStep === 'promotion') {
                    handleCommitStep('promotion', 'poster');
                  } else {
                    // Step mapping helper inside 4Ps tabs
                    const sequence = ['product', 'pricing', 'place', 'promotion'];
                    const curIndex = sequence.indexOf(activeStep);
                    handleCommitStep(activeStep, sequence[curIndex + 1]);
                  }
                }}
              />
            </motion.div>
          )}

          {/* STEP: POSTER PRESENTATION CHECK */}
          {activeStep === 'poster' && (
            <motion.div
              key="poster"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <FinalPoster
                plan={planState}
                onReset={handleResetSession}
                presetEmoji={getPresetEmoji()}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Persistent Page-Footer */}
      <footer className="bg-white border-t-2 border-slate-100 py-5 text-center mt-12">
        <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">
          🏆 Launchpad Biz Kid Academy • Designed with ❤️ for School Entrepreneurship Fairs
        </p>
      </footer>
    </div>
  );
}

export interface TargetHero {
  heroName: string;
  heroAge: number; // e.g. 10 to 14
  heroHobby: string;
  heroPainPoint: string;
  heroHangout: string;
}

export interface PositioningMadLibs {
  targetHero: string;
  problem: string;
  competitor: string;
  uniqueFeature: string;
  brandValue: string;
}

export interface FourPsState {
  productFeatures: string[];
  productPackaging: string;
  costToMake: number;
  sellingPrice: number;
  placesToSell: string[];
  promoStrategies: string[];
  promoChannels?: string[];
}

export interface MarketingPlanState {
  id: string;
  presetKey: string; // 'glow_cupcake' | 'eco_skateboard' | 'pet_lingo' | 'solar_backpack' | 'custom'
  productTitle: string;
  productDescription: string;
  segmentation: TargetHero;
  positioning: PositioningMadLibs;
  fourPs: FourPsState;
  completedSteps: string[]; // e.g. 'setup', 'segmentation', 'positioning', 'product', 'pricing', 'place', 'promotion'
}

export interface PresetBusiness {
  key: string;
  title: string;
  emoji: string;
  category: string;
  description: string;
  suggestedSegment: Partial<TargetHero>;
  suggestedPositioning: Partial<PositioningMadLibs>;
  suggestedFourPs: Partial<FourPsState>;
}

import { PresetBusiness } from './types';

export const PRESETS: PresetBusiness[] = [
  {
    key: 'smart_backpack',
    title: 'Smart Power-Backpack',
    emoji: '🎒',
    category: 'Tech & Gear',
    description: 'Sleek, splash-proof backpacks woven with durable solar threads that easily charge smartphones during outdoor play, featuring built-in wireless pockets and customizable scrolling LED pixel sheets.',
    suggestedSegment: {
      heroName: 'Tech-Savvy Tyler',
      heroAge: 13,
      heroHobby: 'Mobile gaming, gadget building, and skatepark meetups',
      heroPainPoint: 'Devices constantly running low on battery power during after-school hangouts with zero outlets nearby',
      heroHangout: 'Robotics labs, Discord chat servers, and backyard community parks'
    },
    suggestedPositioning: {
      targetHero: 'gadget-loving teenagers',
      problem: 'devices draining battery right when they need to call home or coordinate with friends',
      competitor: 'boring, heavy old-school nylon bookbags',
      uniqueFeature: 'integrated comfortable solar wire fabrics and programmable glowing LED status grids',
      brandValue: 'staying fully charged, secure, and looking futuristic wherever you walk'
    },
    suggestedFourPs: {
      productFeatures: ['Flexible solar-thread weaver panels', 'Hidden anti-theft GPS locator pocket', 'Dynamic Bluetooth LED pixel panel'],
      productPackaging: 'Reusable heavy-duty cardboard tube cylinder',
      costToMake: 15.0,
      sellingPrice: 49.0,
      placesToSell: ['🎒 School catalog flyer', '🏫 School Bake Sales & Tuck Shop', 'Local weekend pop-up markets', 'Online youth electronics store'],
      promoStrategies: ['🎥 Record a fun TikTok / Reel unboxing the solar thread', '🎒 Distribute holographic stickers with product logos', '🎟️ Launch Day Buy-1-Get-1 codes for early signups'],
      promoChannels: ['📱 Instagram & TikTok accounts', '🏫 School lunchrooms & hallways', '🎮 Roblox, Fortnite & Discord chat rooms']
    }
  },
  {
    key: 'smart_water_bottle',
    title: 'HydroGlow Smart Bottle',
    emoji: '💧',
    category: 'Fitness & Smart Tech',
    description: 'An insulated smart bottle that tracks teen sports hydration levels, alerts kids to sip water using beautiful custom glow rings, and self-cleans its interior using safe, integrated UV-light cells.',
    suggestedSegment: {
      heroName: 'Active Abby',
      heroAge: 12,
      heroHobby: 'Playing varsity soccer, street dancing, and editing sports clips',
      heroPainPoint: 'Getting tired, dehydrated, or forgetful in the middle of long hot weekend soccer practice drills',
      heroHangout: 'Municipal sports fields, health smoothie cafes, and dance studios'
    },
    suggestedPositioning: {
      targetHero: 'active student athletes',
      problem: 'forgetting to stay hydrated during intense physical workouts',
      competitor: 'generic plastic water flasks that get warm and smelly over time',
      uniqueFeature: 'animated color-changing LED glow indicators and automatic UV cleaning filters',
      brandValue: 'turning healthy hydration habits into an exciting game'
    },
    suggestedFourPs: {
      productFeatures: ['LED hydration reminder glow rings', 'Self-cleaning UV-C sensor cap', 'Double-wall cooling insulation steel'],
      productPackaging: 'Biodegradable bamboo canister wrapped in natural fibers',
      costToMake: 8.0,
      sellingPrice: 24.5,
      placesToSell: ['🎁 Pop-up Stands at Sports Parks', 'Local youth athletic centers', 'E-commerce web store'],
      promoStrategies: ['🎥 Record a fun TikTok / Reel showing the self-cleaning light', '🎁 Give free trials to classmates to build social proof', '🎤 Presentation pitch during recess describing hydration hacks'],
      promoChannels: ['🏫 School lunchrooms & hallways', '📱 Instagram & TikTok accounts', '🎪 Local hobby shops & market pin-boards']
    }
  },
  {
    key: 'sport_shoes',
    title: 'AeroStride Smart Trainer Shoes',
    emoji: '👟',
    category: 'Athletic Gear',
    description: 'High-traction training running shoes fitted with built-in insoles containing pressure sensors that correct track posture, self-tensioning smart laces, and high-impact orthopedic foam.',
    suggestedSegment: {
      heroName: 'Track Star Tristan',
      heroAge: 14,
      heroHobby: 'Running track sprints, playing backyard basketball, and learning fitness routines',
      heroPainPoint: 'Suffering from sore joints and poor running landing form using cheap, heavy sneakers',
      heroHangout: 'School field lanes, public basketball courts, and track gym galleries'
    },
    suggestedPositioning: {
      targetHero: 'hardworking junior high athletics runners',
      problem: 'posture misalignment and heavy impact stress from common non-supportive athletic sneakers',
      competitor: 'expensive classic lifestyle sneakers designed only for looks but lacking running feedback',
      uniqueFeature: 'smart-insoles measuring and correction landing angles through connected Bluetooth audio charts',
      brandValue: 'improving individual athletic speeds while protecting developing joints'
    },
    suggestedFourPs: {
      productFeatures: ['In-sole gait and impact motion sensors', 'Auto-fitting self-tightening adaptive laces', 'Ultra-absorbing air-cushion cellular soles'],
      productPackaging: 'Transformable cardboard shoebox that flat-packs into an agility fitness ladder',
      costToMake: 25.0,
      sellingPrice: 79.5,
      placesToSell: ['Local teenage sports clubhouses', 'Track-and-field junior expos', 'Direct team-order catalog sheets'],
      promoStrategies: ['🎤 Presentation pitch during recess detailing smart stats', '🎟️ Launch Day Buy-1-Get-1 codes for school team runners', '🎒 Distribute holographic stickers for laptop boards'],
      promoChannels: ['🏫 School lunchrooms & hallways', '📱 Instagram & TikTok accounts', '🎮 Roblox, Fortnite & Discord chat rooms']
    }
  },
  {
    key: 'smart_lunchbox',
    title: 'BentoByte Smart Lunchbox',
    emoji: '🍱',
    category: 'School Gear & Food Tech',
    description: 'An premium electronic smart lunchbox split into separate auto-heating and active-chilling compartments, secured with magnetic spill-proof lids and an integrated allergen hazard scanner.',
    suggestedSegment: {
      heroName: 'Safety-First Alex',
      heroAge: 11,
      heroHobby: 'Science club experiments, gourmet baking, and inventing gadgets',
      heroPainPoint: 'Lukewarm soggy lunch meals and constant worry about accidental dairy or peanut allergen touch-crosses in the cafeteria',
      heroHangout: 'Robotics labs, school lunch halls, and family baking channels'
    },
    suggestedPositioning: {
      targetHero: 'school children desiring hot, safe food',
      problem: 'soggy packed food losing temperature and cafeteria tables being cross-contaminated',
      competitor: 'flimsy plastic food boxes and leaking insulated canvas bags',
      uniqueFeature: 'individual hot-to-cold thermal zones coupled with barcode scanner safety notifications',
      brandValue: 'making school lunches completely stress-free, steaming fresh, and fun'
    },
    suggestedFourPs: {
      productFeatures: ['Dual zone thermo-controlled electric plates', 'Instant barcode allergen indicator screen', 'Spill-resistant double-click magnetic seal'],
      productPackaging: 'Edible, compostable organic packaging wrapping containing flowery seeds',
      costToMake: 10.0,
      sellingPrice: 29.5,
      placesToSell: ['🏫 School Bake Sales & Tuck Shop', '🎒 School catalog flyer', 'Parent parenting forums and blogs'],
      promoStrategies: ['🎥 Record a fun TikTok / Reel with a steaming-fresh meal reveal', '🎁 Give free trials to classmates in the STEM club', '🎟️ Launch Day Buy-1-Get-1 codes for parent blogs'],
      promoChannels: ['🏫 School lunchrooms & hallways', '📱 Instagram & TikTok accounts', '🎪 Local hobby shops & market pin-boards']
    }
  }
];

export const ALL_STEP_KEYS = [
  'setup',
  'segmentation',
  'positioning',
  'product',
  'pricing',
  'place',
  'promotion',
  'poster'
];

export const BADGES = [
  {
    id: 'badge_segmentation',
    title: 'Audience Detective',
    description: 'Discovered who your prime customer is and created an incredible Target Hero Profile Card!',
    emoji: '🔍',
    unlockedBy: 'segmentation'
  },
  {
    id: 'badge_positioning',
    title: 'Secret Sauce Finder',
    description: 'Completed the Positioning Mad Libs formula and set your business apart from heavy rivals!',
    emoji: '🍯',
    unlockedBy: 'positioning'
  },
  {
    id: 'badge_product',
    title: 'Master Craftsman',
    description: 'Defined the unique features, traits, and gorgeous packaging of your product!',
    emoji: '🛠️',
    unlockedBy: 'product'
  },
  {
    id: 'badge_pricing',
    title: 'Pricing Architect',
    description: 'Completed the Profit Math Lab, analyzed the margins, and launched the final prices!',
    emoji: '💰',
    unlockedBy: 'pricing'
  },
  {
    id: 'badge_market_mix',
    title: 'Marketing Champion',
    description: 'Finalized the Place and Promotion channels to lock down a masterful 4Ps strategy!',
    emoji: '📣',
    unlockedBy: 'promotion'
  }
];

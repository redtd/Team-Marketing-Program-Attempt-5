import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

// Initialize Gemini safely
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// API endpoint for generating product features or packaging
app.post("/api/generate", async (req, res) => {
  try {
    const { productTitle, productDescription, type } = req.body;

    if (!productTitle) {
      return res.status(400).json({ error: "Product title is required." });
    }

    if (!ai) {
      return res.status(500).json({
        error: "Gemini API key is not configured. Please add GEMINI_API_KEY in Settings > Secrets."
      });
    }

    if (type === "features") {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Generate 3 awesome, innovative, and fun features for a teen startup product.
Title: ${productTitle}
Description: ${productDescription || ""}
The features should be appealing to middle/high school students, practical yet futuristic.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              features: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Exactly 3 distinct awesome features or product details."
              }
            },
            required: ["features"]
          }
        }
      });

      const parsed = JSON.parse(response.text?.trim() || "{}");
      return res.json({ features: parsed.features || [] });
    } else if (type === "packaging") {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Generate a creative, eco-friendly, and cool packaging design idea for a teen startup product.
Title: ${productTitle}
Description: ${productDescription || ""}
The packaging should have a fun name or gimmick that appeals to students and stands out at school. Limit to 15 words or less.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              packaging: {
                type: Type.STRING,
                description: "Cool eco-friendly packaging description (15 words max)."
              }
            },
            required: ["packaging"]
          }
        }
      });

      const parsed = JSON.parse(response.text?.trim() || "{}");
      return res.json({ packaging: parsed.packaging || "" });
    } else {
      return res.status(400).json({ error: "Invalid type requested. Must be 'features' or 'packaging'." });
    }
  } catch (error: any) {
    console.error("Gemini Generation Error:", error);
    return res.status(500).json({ error: error.message || "Failed to generate ideas with Gemini." });
  }
});

// Vite middleware or client-side assets serving
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

setupVite().catch((err) => {
  console.error("Failed to boot Express-Vite backend:", err);
});
